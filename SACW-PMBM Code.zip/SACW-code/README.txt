<file path="README.md">
# SACW-PMBM 仿真平台

这是一个用于评估和比较基于泊松多伯努利混合（PMBM）滤波器的多目标跟踪算法的MATLAB仿真平台。该平台实现了论文《A Divide-and-Conquer Fusion Algorithm for Multi-Target Tracking in Multi-Sensor Networks Based on the PMBM Filter》中提出的SACW-PMBM算法，并将其与三种基准算法进行比较：
1.  **中心化 PMBM (C-PMBM)**
2.  **加权算术平均 PMBM (WAA-PMBM)**
3.  **广义协方差交集 PMBM (GCI-PMBM)**

该平台的核心是实现一个“高挑战性”仿真场景，旨在突出空间自适应融合的优势。

## 文件结构

- `main_simulation_loop.m`: 仿真的主入口脚本。它负责设置参数，运行蒙特卡洛仿真，并调用其他模块进行评估和绘图。
- `simulation_config.m`: 包含所有仿真参数的配置文件，如传感器网络布局、目标模型、杂波率等。
- `/environment`: 包含生成仿真环境的函数。
  - `generate_ground_truth.m`: 生成并更新目标的真实轨迹。
  - `sensor_model.m`: 根据真实目标状态和传感器特性（包括高挑战性场景的设置）生成传感器测量值。
- `/filters`: 包含四种跟踪算法的核心实现。
  - `run_C_PMBM.m`: 运行中心化PMBM滤波器。
  - `run_WAA_PMBM.m`: 运行WAA-PMBM分布式滤波器。
  - `run_GCI_PMBM.m`: 运行GCI-PMBM分布式滤波器。
  - `run_SACW_PMBM.m`: 运行所提出的SACW-PMBM分布式滤波器。
- `/components`: 包含PMBM滤波器和融合算法的共享组件。
  - `pmbm_predict_step.m`: 实现PMBM的预测步骤。
  - `pmbm_update_step.m`: 实现标准PMBM的更新步骤（用于C-PMBM和局部滤波器）。
  - `pmbm_extract_state.m`: 从PMBM后验中提取目标状态估计。
  - `prune_and_merge.m`: 对PMBM假设进行剪枝和合并以控制计算复杂度。
  - `fuse_WAA.m`: 实现WAA融合规则。
  - `fuse_GCI.m`: 实现GCI融合规则。
  - `fuse_SACW.m`: 实现SACW融合规则。
  - `calculate_confidence_weights.m`: SACW-PMBM的关键部分，实现了VAE的功能代理，用于计算空间自适应权重。
- `/evaluation`: 包含性能评估模块。
  - `evaluate_performance.m`: 计算所有性能指标（OSPA, GOSPA, RMSE, 势估计, TFR, IDSW）。
  - `calculate_ospa.m`: 计算OSPA和GOSPA距离。
  - `calculate_track_metrics.m`: 计算基于航迹的指标（TFR, IDSW）。
  - `assign_tracks_hungarian.m`: 使用匈牙利算法进行真值航迹和估计航迹的全局分配。
- `/plotting`: 包含结果可视化模块。
  - `plot_results.m`: 生成所有图表和表格。

## 如何运行

1.  打开MATLAB。
2.  将所有文件和文件夹放在同一个工作目录中。
3.  在 `simulation_config.m` 中检查并根据需要调整参数（例如，`num_mc_runs`）。
4.  运行主脚本 `main_simulation_loop.m`。

仿真完成后，所有性能图表和表格将自动生成并显示。