% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     REPLACEMENT for pmbm_update_step.m
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmbm_updated = pmbm_update_step(pmbm_pred, Zk, sensor_model, config)
    % Implements a more robust PMBM update step, suitable for high-challenge scenarios.
    % This version includes:
    % - A proper PPP update for missed detections.
    % - Creation of new Bernoulli components (potential tracks) from the PPP.
    % - Gated assignment-based data association (using Hungarian algorithm).
    % - Likelihood-based updates for existence probabilities.

    pmbm_updated = pmbm_pred;
    if isempty(Zk)
        % If there are no measurements, all existing tracks are miss-detected
        if ~isempty(pmbm_updated.MBM)
            for h = 1:length(pmbm_updated.MBM)
                for i = 1:length(pmbm_updated.MBM{h}.tracks)
                    track = pmbm_updated.MBM{h}.tracks{i};
                    % Get state-dependent Pd
                    pd = get_state_dependent_pd(track.m, sensor_model, config);
                    track.r = track.r * (1 - pd);
                    pmbm_updated.MBM{h}.tracks{i} = track;
                end
            end
        end
        return;
    end

    % --- 1. Preparation and Coordinate Conversion ---
    if isfield(sensor_model, 'pos')
        Zk_cart = [];
        sensor_pos = sensor_model.pos;
        for i = 1:size(Zk, 2)
            r = Zk(1,i); theta = Zk(2,i);
            x = sensor_pos(1) + r * cos(theta);
            y = sensor_pos(2) + r * sin(theta);
            Zk_cart = [Zk_cart, [x; y]];
        end
    else
        Zk_cart = Zk;
    end

    num_meas = size(Zk_cart, 2);

    % --- 2. Update existing tracks (using single best hypothesis) ---
    if isempty(pmbm_pred.MBM)
        best_hyp.tracks = {};
        best_hyp.w = 1.0;
        best_hyp.id_counter = 0;
    else
        % For simplicity, we continue to work on the single most likely hypothesis
        [~, best_hyp_idx] = max([pmbm_pred.MBM{:}.w]);
        best_hyp = pmbm_pred.MBM{best_hyp_idx};
    end

    num_tracks = length(best_hyp.tracks);
    updated_tracks = cell(1, num_tracks);

    % --- 3. Gating and Cost Matrix Calculation ---
    cost_matrix = inf(num_tracks, num_meas);
    H = [1 0 0 0; 0 0 1 0];
    R_cartesian = diag([15^2, 15^2]); % Approximate Cartesian noise

    for i = 1:num_tracks
        track = best_hyp.tracks{i};
        S = H * track.P * H' + R_cartesian;
        S_inv = inv(S);

        for j = 1:num_meas
            innov = Zk_cart(:,j) - H * track.m;
            if innov' * S_inv * innov < config.filter.merging_threshold^2 % Gating
                % Cost is negative log-likelihood
                cost_matrix(i, j) = 0.5 * log(det(2*pi*S)) + 0.5 * innov' * S_inv * innov;
            end
        end
    end

    % --- 4. Data Association using Hungarian Algorithm ---
    cost_of_non_assignment = -log(1e-15); % A high cost for non-assignment
    [assignment, unassigned_tracks, unassigned_meas] = matchpairs(cost_matrix, cost_of_non_assignment);

    % --- 5. Update Matched Tracks ---
    for i = 1:size(assignment, 1)
        track_idx = assignment(i, 1);
        meas_idx = assignment(i, 2);

        track = best_hyp.tracks{track_idx};
        z = Zk_cart(:, meas_idx);

        % KF Update
        S = H * track.P * H' + R_cartesian;
        K = track.P * H' / S;
        innov = z - H * track.m;
        track.m = track.m + K * innov;
        track.P = (eye(4) - K * H) * track.P;

        % Likelihood-based existence update
        pd = get_state_dependent_pd(track.m, sensor_model, config);
        likelihood = mvnpdf(z', (H * track.m)', S);
        clutter_intensity = num_meas / (pi * config.sensor.max_range^2); % Simplified

        if clutter_intensity > 0
            likelihood_ratio = (pd * likelihood) / clutter_intensity;
            track.r = (track.r * likelihood_ratio) / (1 - track.r + track.r * likelihood_ratio);
            track.r = min(track.r, 0.999);
        else
            track.r = 0.999; % Detected, so high confidence
        end
        updated_tracks{track_idx} = track;
    end

    % --- 6. Update Miss-Detected Tracks ---
    for i = 1:length(unassigned_tracks)
        track_idx = unassigned_tracks(i);
        track = best_hyp.tracks{track_idx};
        pd = get_state_dependent_pd(track.m, sensor_model, config);
        track.r = track.r * (1 - pd);
        updated_tracks{track_idx} = track;
    end

    % --- 7. Create New Tracks from Unassigned Measurements (PPP update) ---
    new_tracks = {};
    birth_prob = exp(pmbm_pred.ppp.w); % Simplified PPP intensity

    for i = 1:length(unassigned_meas)
        meas_idx = unassigned_meas(i);
        z = Zk_cart(:, meas_idx);
        clutter_intensity = num_meas / (pi * config.sensor.max_range^2);

        % Probability that this measurement is a new target
        r_new = birth_prob / (birth_prob + clutter_intensity);

        % Only create new tracks if they are sufficiently likely
        if r_new > config.filter.pruning_threshold 
            new_track.m = [z(1); 0; z(2); 0];
            new_track.P = diag([100^2, 50^2, 100^2, 50^2]);
            new_track.r = r_new;
            best_hyp.id_counter = best_hyp.id_counter + 1;
            new_track.id = best_hyp.id_counter;
            new_tracks{end+1} = new_track;
        end
    end

    % --- 8. Combine, Prune, and Finalize ---
    all_tracks = [updated_tracks(~cellfun('isempty', updated_tracks)), new_tracks];

    % Prune tracks with low existence probability
    final_tracks = {};
    for i = 1:length(all_tracks)
        if all_tracks{i}.r > config.filter.pruning_threshold
            final_tracks{end+1} = all_tracks{i};
        end
    end

    best_hyp.tracks = final_tracks;
    pmbm_updated.MBM = {best_hyp};
end

function pd = get_state_dependent_pd(state_vec, sensor_model, config)
% Helper function to calculate state-dependent probability of detection
    pd = config.filter.p_d; % Baseline Pd
    track_pos = state_vec([1, 3]);

    % Check for occlusion if sensor ID is available (distributed case)
    if isfield(sensor_model, 'id') 
        if ismember(sensor_model.id, config.occlusion.sensors_affected)
            occ_rect = config.occlusion.rect;
            if track_pos(1) > occ_rect(1) && track_pos(1) < occ_rect(2) &&...
               track_pos(2) > occ_rect(3) && track_pos(2) < occ_rect(4)
                pd = config.occlusion.pd_inside;
            end
        end
    end
end