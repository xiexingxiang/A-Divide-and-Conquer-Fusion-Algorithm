%<file path="components/calculate_confidence_weights.m">
function [idx_min_sensor,weights] = calculate_confidence_weights(target_pos, local_pmbms, config)
    % This is a functional proxy for the VAE-based confidence field model.
    % It calculates state-dependent weights omega_s(x) for a given target position x.
    
    num_sensors = config.sensor.num_sensors;
    weights_unnormalized = zeros(1, num_sensors);
    
    for s = 1:num_sensors
        % --- 1. Calculate Environmental Disturbance Factor (gamma) ---
        gamma = 0;
        
        % a. FoV effect
        sensor_pos = config.sensor.positions(s, :);
        target_bearing = atan2(target_pos(2) - sensor_pos(2), target_pos(1) - sensor_pos(1));
        if config.sensor.fov(s) < 360
            sensor_orientation = atan2(-sensor_pos(2), -sensor_pos(1));
            angle_diff = abs(angdiff(target_bearing, sensor_orientation));
            if angle_diff > deg2rad(config.sensor.fov(s)) / 2
                gamma = gamma + 5; % High penalty for being outside FoV
            end
        end
        
        % b. Occlusion effect
        if ismember(s, config.occlusion.sensors_affected)
            occ_rect = config.occlusion.rect;
            if target_pos(1) > occ_rect(1) && target_pos(1) < occ_rect(2) &&...
               target_pos(2) > occ_rect(3) && target_pos(2) < occ_rect(4)
                gamma = gamma + 3; % Penalty for being in occlusion zone
            end
        end
        
        % c. Clutter hotspot effect
        if norm(target_pos - config.clutter.hotspot_center) < config.clutter.hotspot_radius
            gamma = gamma + 2; % Penalty for being in clutter hotspot
        end
        
        % d. Distance effect (proxy for SNR)
        dist_to_sensor = norm(target_pos - sensor_pos);
        gamma = gamma + (dist_to_sensor / config.sensor.max_range); % Linear penalty with distance
        
        % --- 2. Calculate Information Entropy (H) ---
        % This is a proxy. True entropy requires complex integration.
        % We use the determinant of the covariance of the nearest track as a proxy for uncertainty.
        H = 0;idx_min = [];
        if ~isempty(local_pmbms{s}.MBM) && isfield(local_pmbms{s}.MBM{1}, 'tracks')
            min_dist = inf;
            best_P = [];
            for i = 1:length(local_pmbms{s}.MBM{1}.tracks)
                dist = norm(target_pos - local_pmbms{s}.MBM{1}.tracks{i}.m([1, 3]));
                if dist < min_dist
                    min_dist = dist;
                    best_P = local_pmbms{s}.MBM{1}.tracks{i}.P;
                    idx_min = i;
                end
            end
            if ~isempty(best_P)
                H = 0.1 * log(det(best_P)); % Scale factor is heuristic
                if min_dist>config.filter.sacw_multi_merging_threshold
                    idx_min=0;
                end
            end
        end
        
        % --- 3. Synthesize weight using Sigmoid function (from paper Eq. 12) ---
        % We want high confidence (low value) to result in high weight.
        % The paper's formula implies omega is the confidence itself.
        % Let's define confidence = 1 / (alpha*H + (1-alpha)*gamma)
        % A simpler interpretation: confidence is inversely proportional to the combined factor.
        
        alpha = config.sacw.alpha;
        beta = config.sacw.beta;
        
        % The value inside the sigmoid should be negative for high confidence
        % and positive for low confidence.
        % Let's define a "cost" = alpha*H + (1-alpha)*beta*gamma
        % Then confidence = 1 - sigmoid(cost - C) where C is a bias.
        % For simplicity, we'll use an inverse relationship.
        
        cost = alpha * max(0, H) + (1 - alpha) * beta * gamma;
        weights_unnormalized(s) = exp(-cost);
        if isempty(idx_min)
            idx_min_sensor(s) = 0;
        else
        idx_min_sensor(s) = idx_min;
        end
    end
    
    % Normalize weights to sum to 1
    weights_unnormalized(~idx_min_sensor) = 0;
    total_weight = sum(weights_unnormalized);
    if total_weight > 0
        weights = weights_unnormalized / total_weight;
    else
        weights = ones(1, num_sensors) / num_sensors; % Fallback
    end
end