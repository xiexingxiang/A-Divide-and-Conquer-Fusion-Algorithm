%<file path="components/calculate_confidence_weights.m">
function [idx_min_sensor,weights] = calculate_gci_weights(target_pos, local_pmbms, config)

num_sensors = config.sensor.num_sensors;

for s = 1:num_sensors

    idx_min = [];
    if ~isempty(local_pmbms{s}.MBM) && isfield(local_pmbms{s}.MBM{1}, 'tracks')
        min_dist = inf;
        best_P = [];
        for i = 1:length(local_pmbms{s}.MBM{1}.tracks)
            dist = norm(target_pos - local_pmbms{s}.MBM{1}.tracks{i}.m([1, 3]));
            if dist < min_dist
                min_dist = dist;
                best_P = local_pmbms{s}.MBM{1}.tracks{i}.P;
                idx_min = i;
            end
        end

        if ~isempty(best_P)
            pos_cov = best_P([1 3], [1 3]);  % Extract position covariance
            info_metrics(s) = 1 / sqrt(det(pos_cov));  % Larger value = more certain
            if min_dist>config.filter.gci_multi_merging_threshold
                idx_min=0;
            end
        else
            info_metrics(s) = 0;
        end
    end

    if isempty(idx_min)
        idx_min_sensor(s) = 0;
    else
        idx_min_sensor(s) = idx_min;
    end
end

% Normalize weights to sum to 1
info_metrics(~idx_min_sensor) = 0;
total_weight = sum(info_metrics);
if total_weight > 0
    weights = info_metrics / total_weight;
else
    weights = ones(1, num_sensors) / num_sensors; % Fallback
end
end