%<file path="evaluation/calculate_ospa.m">
function [ospa_dist, gospa_dist] = calculate_ospa(X, Y, c, p, alpha)
    % Calculates the OSPA and GOSPA distance between two sets of points X and Y.
    % X: estimated set (2 x n)
    % Y: true set (2 x m)
    
    if isempty(X) && isempty(Y)
        ospa_dist = 0;
        gospa_dist = 0;
        return;
    end

    n = size(X, 2);
    m = size(Y, 2);

    if m > n
        % Swap to ensure m <= n
        temp = X; X = Y; Y = temp;
        temp_n = n; n = m; m = temp_n;
    end

    % Calculate cost matrix of distances
    cost_matrix = zeros(m, n);
    for i = 1:m
        for j = 1:n
            dist = norm(Y(:,i) - X(:,j));
            cost_matrix(i,j) = min(c, dist)^p;
        end
    end
 
    % Find optimal assignment (minimum cost) using Hungarian algorithm
    % matchpairs returns the assignments, not the total cost.
    assignment = matchpairs(cost_matrix, c^p);
    
    % Manually calculate the total cost of the assignment from the cost matrix
    if ~isempty(assignment)
        % Convert 2D indices to linear indices to extract costs efficiently
        linear_indices = sub2ind(size(cost_matrix), assignment(:,1), assignment(:,2));
        cost = sum(cost_matrix(linear_indices));
    else
        cost = 0;
    end
    
    % Calculate OSPA
    if m == 0 % All false positives
        ospa_dist = c;
    else
        ospa_dist = ( (1/n) * (cost + c^p * (n - m)) )^(1/p);
    end

    
    % Calculate GOSPA
    if nargout > 1
        loc_cost = cost;
        miss_cost = c^p/2 * (m - size(assignment,1));
        false_cost = c^p/2 * (n - size(assignment,1));
        gospa_dist = (loc_cost + miss_cost + false_cost)^(1/p);
    end
end