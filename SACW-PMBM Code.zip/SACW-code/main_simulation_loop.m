%<file path="main_simulation_loop.m">
%% Main Simulation Loop for Multi-Target Tracking Algorithm Comparison
% This script orchestrates the entire simulation process. It initializes parameters,
% runs Monte Carlo simulations for four different tracking algorithms, evaluates
% their performance, and plots the results.
clc;
clear all;
close all;
dbstop if error
%rng("default");
tic;

addpath(genpath(pwd)); % Add all subfolders to path

fprintf('Starting multi-target tracking simulation...\n');

% --- 1. Load Simulation Configuration ---
config = simulation_config();
fprintf('Loaded simulation configuration.\n');
fprintf('Number of Monte Carlo runs: %d\n', config.num_mc_runs);
fprintf('Simulation time steps: %d\n', config.sim_steps);

% --- 2. Initialize Data Storage ---
% Store results for all algorithms and all Monte Carlo runs
results = struct();
algorithms = {'SACW_PMBM', 'C_PMBM', 'WAA_PMBM', 'GCI_PMBM'};
for i = 1:length(algorithms)
    alg = algorithms{i};
    results.(alg).ospa = zeros(config.sim_steps, config.num_mc_runs);
    results.(alg).gospa = zeros(config.sim_steps, config.num_mc_runs);
    results.(alg).rmse = zeros(config.sim_steps, config.num_mc_runs);
    results.(alg).card_est = zeros(config.sim_steps, config.num_mc_runs);
    results.(alg).card_true = zeros(config.sim_steps, config.num_mc_runs);
    results.(alg).tracks = cell(1, config.num_mc_runs);
    results.(alg).ground_truth = cell(1, config.num_mc_runs);
end

    % % Generate ground truth for this run 纯直线 Pure CV
    % [ground_truth_states, ground_truth_card] = generate_ground_truth(config);

    % Generate ground truth for this run 带转弯 CV+CT
    [ground_truth_states, ground_truth_card] = generate_ground_truth1(config);
    % --- 3. Main Monte Carlo Loop ---
for mc = 1:config.num_mc_runs
    fprintf('\n--- Monte Carlo Run: %d of %d ---\n', mc, config.num_mc_runs);
    % Store ground truth for evaluation
    for i = 1:length(algorithms)
        results.(algorithms{i}).ground_truth{mc} = ground_truth_states;
    end
    results.SACW_PMBM.card_true(:, mc) = ground_truth_card; % Store once is enough

    % Generate all sensor measurements for this run
    all_measurements = cell(config.sim_steps, 1);
    for k = 1:config.sim_steps
        all_measurements{k} = sensor_model(ground_truth_states{k}, config);
    end

    % --- Run each algorithm ---
    fprintf('Running SACW-PMBM...\n');
    % Corrected Line: Assign function outputs to variables
    [results.SACW_PMBM.tracks{mc}, est_card_sacw] = run_SACW_PMBM(all_measurements, config,ground_truth_states);
    results.SACW_PMBM.card_est(:, mc) = est_card_sacw;

    fprintf('Running C-PMBM...\n');
    % Corrected Line: Assign function outputs to variables
    [results.C_PMBM.tracks{mc}, est_card_c] = run_C_PMBM(all_measurements, config,ground_truth_states);
    results.C_PMBM.card_est(:, mc) = est_card_c;

    fprintf('Running WAA-PMBM...\n');
    % Corrected Line: Assign function outputs to variables
    [results.WAA_PMBM.tracks{mc}, est_card_waa] = run_WAA_PMBM(all_measurements, config,ground_truth_states);
    results.WAA_PMBM.card_est(:, mc) = est_card_waa;

    fprintf('Running GCI-PMBM...\n');
    % Corrected Line: Assign function outputs to variables
    [results.GCI_PMBM.tracks{mc}, est_card_gci] = run_GCI_PMBM(all_measurements, config,ground_truth_states);
    results.GCI_PMBM.card_est(:, mc) = est_card_gci;
    
    % --- Evaluate performance for this run ---
    fprintf('Evaluating performance for run %d...\n', mc);
    for i = 1:length(algorithms)
        alg = algorithms{i};
        [ospa_mc, gospa_mc, rmse_mc] = evaluate_performance(results.(alg).tracks{mc}, ground_truth_states, config);
        results.(alg).ospa(:, mc) = ospa_mc;
        results.(alg).gospa(:, mc) = gospa_mc;
        results.(alg).rmse(:, mc) = rmse_mc;
    end
end

% --- 4. Process and Plot Results ---
fprintf('\n--- Simulation Complete. Processing and plotting results... ---\n');
plot_results1(results, config);

fprintf('All tasks finished.\n');

toc;