%<file path="filters/run_C_PMBM.m">
function [estimated_tracks, estimated_card] = run_C_PMBM(all_measurements, config,ground_truth_states)
% Runs the Centralized PMBM filter.
% All measurements are pooled and processed by a single filter.
if config.filter.plot_tra
    % --- Plot Ground Truth Trajectories ---
    figure;
    hold on;
    title('Ground Truth Trajectories');
    xlabel('X Position');
    ylabel('Y Position');
    for t = 1:config.sim_steps
        % Extract the states for the current time step
        states = ground_truth_states{t};
        % Plot each target's trajectory
        for target_idx = 1:size(states, 2)
            plot(states(1, target_idx), states(3, target_idx), 'o', 'MarkerSize', 1, 'Color',"b");
        end
    end
    grid on;
end
sim_steps = config.sim_steps;
estimated_tracks = cell(sim_steps, 1);
estimated_card = zeros(sim_steps, 1);

% Initialize PMBM filter state
pmbm.ppp.w = log(config.filter.birth_intensity_uniform); % Log-weight for uniform PPP
pmbm.ppp.m = []; % Not used for uniform
pmbm.ppp.P = []; % Not used for uniform
pmbm.MBM = {}; % Array of structs for global hypotheses

for k = 1:sim_steps
    % 1. Pool all measurements from all sensors
    Zk_pooled = [];
    for s = 1:config.sensor.num_sensors
        % Convert polar measurements to Cartesian
        sensor_pos = config.sensor.positions(s,:);
        Zk_s = all_measurements{k}{s};
        for i = 1:size(Zk_s, 2)
            r = Zk_s(1,i);
            theta = Zk_s(2,i);
            x = sensor_pos(1) + r * cos(theta);
            y = sensor_pos(2) + r * sin(theta);
            Zk_pooled = [Zk_pooled, [x; y]];
        end
    end

    % 2. PMBM Prediction
    pmbm = pmbm_predict_step(pmbm, config);

    % 3. PMBM Update
    % For C-PMBM, we need a likelihood function for the pooled measurements
    % This is a simplification. A proper C-PMBM would use the raw
    % multi-sensor likelihood. Here we treat the pooled Cartesian
    % measurements as if from a single "super sensor".
    % The measurement noise covariance needs to be approximated.
    R_cartesian = diag([15^2, 15^2]); % Approximate Cartesian noise

    % Create a dummy sensor model for the update step
    dummy_sensor_model.p_d = config.filter.p_d;
    dummy_sensor_model.clutter_rate = config.clutter.rate_background * config.sensor.num_sensors;
    dummy_sensor_model.H = [1 0 0 0; 0 0 1 0]; % Cartesian measurement model
    dummy_sensor_model.R = R_cartesian;

    pmbm = c_pmbm_update_step(pmbm, Zk_pooled, dummy_sensor_model, config);

    % 4. Pruning and Merging
    pmbm = prune_and_merge(pmbm, config);

    % 5. State Extraction
    estimated_states = pmbm_extract_state(pmbm, config); % <--- 修正
    if config.filter.plot_tra
        if ~isempty(estimated_states)
            states = estimated_states;
            % Plot each target's trajectory
            for target_idx = 1:size(states, 2)
                plot(states(1, target_idx), states(3, target_idx), '+', 'MarkerSize', 6,'Color',"r");
                hold on
            end
        end
    end
    estimated_tracks{k} = estimated_states;
    estimated_card(k) = size(estimated_states, 2);
end
end