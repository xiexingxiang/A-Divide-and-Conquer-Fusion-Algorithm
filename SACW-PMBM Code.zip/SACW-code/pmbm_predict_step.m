%<file path="components/pmbm_predict_step.m">
function pmbm_pred = pmbm_predict_step(pmbm, config)
    % Implements the prediction step for a PMBM filter.
    % This is a simplified implementation assuming uniform PPP and Gaussian Bernoullis.
    
    pmbm_pred = pmbm;
    
    % --- 1. Predict PPP for undetected targets ---
    % This is a simplified prediction for a uniform PPP.
    % It assumes surviving targets remain uniformly distributed.
    % A proper implementation would use Gaussian Mixture PPP.
    % The intensity is the sum of surviving and birth intensities.
    lambda_survival = exp(pmbm.ppp.w) * config.target.ps;
    lambda_birth = config.filter.birth_intensity_uniform;
    pmbm_pred.ppp.w = log(lambda_survival + lambda_birth);
    
    % --- 2. Predict MBM for detected targets ---
    if ~isempty(pmbm.MBM)
        for h = 1:length(pmbm.MBM) % Iterate through global hypotheses
            for i = 1:length(pmbm.MBM{h}.tracks) % Iterate through Bernoulli components
                track = pmbm.MBM{h}.tracks{i};
                
                % Predict existence probability
                r_pred = track.r * config.target.ps;
                
                % Predict state (mean and covariance)
                m_pred = config.target.F_cv * track.m;
                P_pred = config.target.F_cv * track.P * config.target.F_cv' + config.target.Q_cv;
                
                pmbm_pred.MBM{h}.tracks{i}.r = r_pred;
                pmbm_pred.MBM{h}.tracks{i}.m = m_pred;
                pmbm_pred.MBM{h}.tracks{i}.P = P_pred;
            end
        end
    end
end