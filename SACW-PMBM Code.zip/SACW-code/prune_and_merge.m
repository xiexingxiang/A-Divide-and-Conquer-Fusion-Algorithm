function pmbm_out = prune_and_merge(pmbm_in, config)
    % PMBM pruning and merging with state-based component handling
    % (No dependence on target IDs)
    config.prune.hyp_weight_threshold = 1e-2;
    config.prune.max_pos_variance = 40;
    config.merge.similarity_threshold = 0.85;
    config.prune.exist_threshold = 1e-3;
    pmbm_out = pmbm_in;
    
    % Return if no MBM components
    if isempty(pmbm_in.MBM)
        return;
    end
    
    % ===== 1. Global Hypothesis Pruning =====
    hyp_weights = [pmbm_in.MBM{:}.w];
    total_weight = sum(hyp_weights);
    
    % Prune based on weight threshold
    prune_mask = hyp_weights > config.prune.hyp_weight_threshold * total_weight;
    pruned_mbm = pmbm_in.MBM(prune_mask);
    
    % Cap maximum hypotheses
    if length(pruned_mbm) > config.filter.max_hypotheses
        [~, sorted_idx] = sort(hyp_weights(prune_mask), 'descend');
        pruned_mbm = pruned_mbm(sorted_idx(1:config.filter.max_hypotheses));
    end
    
    % Renormalize weights
    new_total_weight = sum([pruned_mbm{:}.w]);
    for h = 1:length(pruned_mbm)
        pruned_mbm{h}.w = pruned_mbm{h}.w / new_total_weight;
    end
    
    % ===== 2. Bernoulli Component Pruning =====
    for h = 1:length(pruned_mbm)
        tracks = pruned_mbm{h}.tracks;
        keep_idx = true(1, length(tracks));
        
        for t = 1:length(tracks)
            % Check existence probability threshold
            if tracks{t}.r < config.prune.exist_threshold
                keep_idx(t) = false;
                continue;
            end
            
            % % Check covariance spread (position uncertainty)
            % pos_cov = tracks{t}.P(1:2, 1:2); % Assume first 2 states are position
            % cov_det = det(pos_cov);
            % if cov_det > config.prune.max_pos_variance
            %     keep_idx(t) = false;
            % end
        end
        
        pruned_mbm{h}.tracks = tracks(keep_idx);
    end
    
    % ===== 3. Hypothesis Merging =====
    if length(pruned_mbm) < 2
        pmbm_out.MBM = pruned_mbm;
        return;
    end
    
    % Build similarity matrix using state-based distances
    similarity_matrix = zeros(length(pruned_mbm));
    for i = 1:length(pruned_mbm)
        for j = i+1:length(pruned_mbm)
            similarity_matrix(i,j) = gaussian_hyp_similarity(...
                pruned_mbm{i}.tracks, pruned_mbm{j}.tracks, config);
            similarity_matrix(j,i) = similarity_matrix(i,j);
        end
    end
    
    % Cluster similar hypotheses
    visited = false(1, length(pruned_mbm));
    merged_mbm = {};
    
    for i = 1:length(pruned_mbm)
        if visited(i), continue; end
        
        cluster_indices = i;
        visited(i) = true;
        
        % Find similar hypotheses
        for j = i+1:length(pruned_mbm)
            if ~visited(j) && similarity_matrix(i,j) > config.merge.similarity_threshold
                cluster_indices(end+1) = j;
                visited(j) = true;
            end
        end
        
        % Merge cluster
        if length(cluster_indices) > 1
            merged_hyp = merge_state_hypotheses(...
                pruned_mbm(cluster_indices), config);
            merged_mbm{end+1} = merged_hyp;
        else
            merged_mbm{end+1} = pruned_mbm{i};
        end
    end
    
    pmbm_out.MBM = merged_mbm;
end

%% Helper function: Gaussian Hypothesis Similarity
function dist = gaussian_hyp_similarity(tracks1, tracks2, config)
    % Calculate state-based distance between two hypotheses using Gaussian mixture
    [X1, P1] = extract_gaussian_mixture(tracks1);
    [X2, P2] = extract_gaussian_mixture(tracks2);
    
    % Compute Gaussian Wasserstein Distance
    dist = 0;
    for i = 1:size(X1, 2)
        min_wd = inf;
        for j = 1:size(X2, 2)
            d_mean = norm(X1(:,i) - X2(:,j));
            d_cov = norm(sqrtm(P1(:,:,i)) - sqrtm(P2(:,:,j)), 'fro');
            wd = sqrt(d_mean^2 + d_cov^2);
            if wd < min_wd
                min_wd = wd;
            end
        end
        dist = dist + min_wd;
    end
    
    % Normalize by maximum possible distance
    max_dist = config.merge.max_dist_per_target * max(size(X1,2), size(X2,2));
    similarity = 1 - min(1, dist/max_dist);
end

%% Helper function: Extract Gaussian Mixture Representation
function [X, P] = extract_gaussian_mixture(tracks)
    % Convert tracks to Gaussian mixture representation
    X = [];
    P = [];
    for k = 1:length(tracks)
        track = tracks{k};
        X = [X, track.m(1:2)];  % Use position states
        P = cat(3, P, track.P(1:2,1:2));
    end
end

%% Helper function: State-based Hypothesis Merging
function merged_hyp = merge_state_hypotheses(hyps, config)
    % Merge hypotheses using state-space clustering
    
    % Calculate combined weight
    weights = [hyps{:}.w];
    total_weight = sum(weights);
    norm_weights = weights / total_weight;
    
    % Collect all tracks from all hypotheses
    all_tracks = [];
    all_hyp_weights = [];
    for h = 1:length(hyps)
        all_tracks = [all_tracks, hyps{h}.tracks];
        all_hyp_weights = [all_hyp_weights, repmat(norm_weights(h), 1, length(hyps{h}.tracks))];
    end
    
    % Cluster tracks by state space position
    if isempty(all_tracks)
        merged_hyp = struct('w', total_weight, 'tracks', {});
        return;
    end
    
    % Extract position means
    positions = zeros(2, length(all_tracks));
    for k = 1:length(all_tracks)
        positions(:,k) = all_tracks{k}.m(1:2);
    end
    
    % DBSCAN clustering of track positions
    [cluster_ids, ~] = dbscan(positions', config.merge.eps, config.merge.min_samples);
    unique_clusters = unique(cluster_ids(cluster_ids > 0));
    
    % Fuse tracks within each cluster
    fused_tracks = {};
    for c = 1:length(unique_clusters)
        cluster_mask = (cluster_ids == unique_clusters(c));
        cluster_tracks = all_tracks(cluster_mask);
        cluster_weights = all_hyp_weights(cluster_mask);
        
        % Only fuse if sufficient confidence
        if length(cluster_tracks) >= config.merge.min_tracks_per_cluster
            % Extract Gaussian parameters
            num_states = size(cluster_tracks{1}.m, 1);
            means = zeros(num_states, length(cluster_tracks));
            covars = zeros(num_states, num_states, length(cluster_tracks));
            exist_probs = zeros(1, length(cluster_tracks));
            
            for k = 1:length(cluster_tracks)
                means(:,k) = cluster_tracks{k}.m;
                covars(:,:,k) = cluster_tracks{k}.P;
                exist_probs(k) = cluster_tracks{k}.r;
            end
            
            % Fuse using Covariance Intersection
            fused_track = fuse_gaussian_mixture(means, covars, exist_probs, cluster_weights, config);
            fused_tracks{end+1} = fused_track;
        end
    end
    
    % Build merged hypothesis
    merged_hyp = struct('w', total_weight, 'tracks', {fused_tracks});
end

%% Helper function: Gaussian Mixture Fusion
function fused_track = fuse_gaussian_mixture(means, covars, exist_probs, weights, config)
    % Fuse a set of Gaussian components
    
    % Normalize weights
    weights = weights / sum(weights);
    
    % Compute fused existence probability
    fused_r = min(1, max(0, sum(weights .* exist_probs)));
    
    % Find component with largest weight as anchor
    [~, main_idx] = max(weights);
    
    % Compute weighted mean and covariance
    fused_mean = means(:,main_idx);
    fused_covar = covars(:,:,main_idx);
    
    % Compute fused covariance (Covariance Intersection)
    w_mat = inv(covars(:,:,main_idx));
    for k = 1:size(means,2)
        if k == main_idx, continue; end
        wk = weights(k) * (inv(covars(:,:,k)) - inv(covars(:,:,main_idx)));
        w_mat = w_mat + wk;
    end
    
    % Compute fused mean
    w_vec = w_mat * fused_mean;
    for k = 1:size(means,2)
        if k == main_idx, continue; end
        wk = weights(k) * (inv(covars(:,:,k)) - inv(covars(:,:,main_idx)));
        w_vec = w_vec + wk * means(:,k);
    end
    
    % Final covariance and mean
    fused_covar = inv(w_mat);
    fused_mean = fused_covar * w_vec;
    
    % Add covariance inflation for conservatism
    fused_covar = fused_covar + config.merge.cov_inflation * eye(size(fused_covar));
    
    % Build fused track
    fused_track = struct('m', fused_mean, 'P', fused_covar, 'r', fused_r);
end

%% Helper function: DBSCAN Clustering
function [idx, corepts] = dbscan(X, epsilon, minpts)
    % DBSCAN clustering algorithm
    n = size(X,1);
    idx = zeros(n,1);
    visited = false(n,1);
    cluster_id = 1;
    
    for i = 1:n
        if visited(i), continue; end
        visited(i) = true;
        
        % Find neighbors
        neighbors = find_neighbors(i, X, epsilon);
        
        if numel(neighbors) < minpts
            % Mark as noise
            idx(i) = -1;
        else
            % Start new cluster
            idx(i) = cluster_id;
            
            % Process neighbors
            seeds = neighbors;
            seeds(seeds==i) = []; % Remove self
            
            while ~isempty(seeds)
                curr = seeds(1);
                seeds(1) = [];
                
                if visited(curr), continue; end
                visited(curr) = true;
                
                curr_neighbors = find_neighbors(curr, X, epsilon);
                if numel(curr_neighbors) >= minpts
                    % Add new neighbors
                    new_seeds = setdiff(curr_neighbors, find(visited));
                    seeds = unique([seeds; new_seeds(:)]);
                end
                
                % Assign to cluster
                if idx(curr) <= 0
                    idx(curr) = cluster_id;
                end
            end
            
            cluster_id = cluster_id + 1;
        end
    end
    
    corepts = idx > 0;
end

function neighbors = find_neighbors(i, X, epsilon)
    % Find neighbors within epsilon distance
    dists = sum((X - repmat(X(i,:), size(X,1), 1)).^2, 2);
    neighbors = find(dists <= epsilon^2);
end

% %<file path="components/prune_and_merge.m">
% function pmbm_out = prune_and_merge(pmbm_in, config)
%     % Performs pruning and merging on the PMBM components to manage complexity.
%     % This is a simplified placeholder.
% 
%     pmbm_out = pmbm_in;
% 
%     if isempty(pmbm_in.MBM)
%         return;
%     end
% 
%     % --- 1. Prune low-weight global hypotheses ---
%     total_weight = 0;
%     for h = 1:length(pmbm_in.MBM)
%         total_weight = total_weight + pmbm_in.MBM{h}.w;
%     end
% 
%     surviving_hyp_idx = [];
%     for h = 1:length(pmbm_in.MBM)
%         if pmbm_in.MBM{h}.w / total_weight > 1e-5 % Hypothesis pruning
%             surviving_hyp_idx = [surviving_hyp_idx, h];
%         end
%     end
% 
% 
%     if length(surviving_hyp_idx) > config.filter.max_hypotheses
%         % 从幸存的假设中，提取它们的权重(w)组成一个向量，然后排序
%         [~, sorted_idx] = sort([pmbm_in.MBM{surviving_hyp_idx}.w], 'descend'); % <--- 修正
%         surviving_hyp_idx = surviving_hyp_idx(sorted_idx(1:config.filter.max_hypotheses));
%     end
% 
%     pmbm_out.MBM = pmbm_in.MBM(surviving_hyp_idx);
% 
%     % Renormalize hypothesis weights  
%     new_total_weight = sum([pmbm_out.MBM{:}.w]); % <--- 修正
%     for h = 1:length(pmbm_out.MBM)
%         pmbm_out.MBM{h}.w = pmbm_out.MBM{h}.w / new_total_weight;
%     end
% 
%     % --- 2. Prune low-probability Bernoulli components within each hypothesis ---
%     % (This is partially handled in the simplified update and extract steps)
% 
%     % --- 3. Merge similar global hypotheses ---
%     % (This is a very complex step and is omitted in this simplified code)
% end