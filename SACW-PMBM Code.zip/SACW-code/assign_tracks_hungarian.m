%<file path="evaluation/assign_tracks_hungarian.m">
function [gt_ids, est_ids, track_mapping] = assign_tracks_hungarian(est_tracks_mc, gt_tracks_mc, config)
    % Performs global assignment between estimated tracks and ground truth tracks
    % over a whole Monte Carlo run using the Hungarian algorithm.
    
    sim_steps = config.sim_steps;
    
    % 1. Collect all unique track IDs
    gt_ids = [];
    est_ids = [];
    for k = 1:sim_steps
        if ~isempty(gt_tracks_mc{k})
            gt_ids = [gt_ids, gt_tracks_mc{k}(5,:)];
        end
        if ~isempty(est_tracks_mc{k})
            est_ids = [est_ids, est_tracks_mc{k}(5,:)];
        end
    end
    gt_ids = unique(gt_ids);
    est_ids = unique(est_ids);
    
 if isempty(gt_ids) || isempty(est_ids)
        track_mapping = [];
        return;
    end
    
    % 2. Build cost matrix based on average distance over lifetime
    cost_matrix = inf(length(gt_ids), length(est_ids));
    
    for i = 1:length(gt_ids)
        for j = 1:length(est_ids)
            total_dist = 0;
            overlap_count = 0;

           for k = 1:sim_steps
                gt_track_k_idx = []; % 先初始化为空
                % 检查在当前时间步k，是否存在真实目标，如果不为空再查找
                if ~isempty(gt_tracks_mc{k})
                    gt_track_k_idx = find(gt_tracks_mc{k}(5,:) == gt_ids(i));
                end
                
                est_track_k_idx = []; % 先初始化为空
                % 检查在当前时间步k，是否存在估计航迹，如果不为空再查找
                if ~isempty(est_tracks_mc{k})
                    est_track_k_idx = find(est_tracks_mc{k}(5,:) == est_ids(j));
                end
                % 只有当两者在当前时间步都存在时，才计算距离
                if ~isempty(gt_track_k_idx) && ~isempty(est_track_k_idx)
                    gt_pos = gt_tracks_mc{k}(1:2, gt_track_k_idx);
                    est_pos = est_tracks_mc{k}(1:2, est_track_k_idx);
                    total_dist = total_dist + norm(gt_pos - est_pos);
                    overlap_count = overlap_count + 1;
                end
            end     


            if overlap_count > 0
                cost_matrix(i, j) = total_dist / overlap_count;
            end
        end
    end
    
    % 3. Solve assignment problem
    [assignment, ~] = matchpairs(cost_matrix, config.eval.ospa_c);
    
    % Return mapping [gt_id, est_id]
    track_mapping = [];
    if ~isempty(assignment)
        track_mapping = [gt_ids(assignment(:,1))', est_ids(assignment(:,2))'];
    end
end