%<file path="environment/sensor_model.m">
function measurements_s = sensor_model(ground_truth_k, config)
    % Generates measurements for all sensors at a single time step k.
    % Implements the high-challenge scenario:
    % - Heterogeneous FoV
    % - Occlusion zone with lower Pd
    % - Clutter hotspot with higher clutter rate

    num_sensors = config.sensor.num_sensors;
    measurements_s = cell(num_sensors, 1);

    for s = 1:num_sensors
        sensor_pos = config.sensor.positions(s, :);
        Z_s = [];

        % --- 1. Generate Detections from True Targets ---
        if ~isempty(ground_truth_k)
            for i = 1:size(ground_truth_k, 2)
                target_state = ground_truth_k(1:4, i);
                target_pos = target_state([1, 3]);

                % Check if target is in sensor range
                dist_to_sensor = norm(target_pos - sensor_pos');
                if dist_to_sensor > config.sensor.max_range
                    continue;
                end

                % Check if target is in sensor FoV
                target_bearing = atan2(target_pos(2) - sensor_pos(2), target_pos(1) - sensor_pos(1));
                sensor_fov_rad = deg2rad(config.sensor.fov(s));
                if sensor_fov_rad < 2*pi
                    % Assuming sensor points towards origin for simplicity
                    sensor_orientation = atan2(-sensor_pos(2), -sensor_pos(1));
                    angle_diff = abs(angdiff(target_bearing, sensor_orientation));
                    if angle_diff > sensor_fov_rad / 2
                        continue;
                    end
                end

                % Determine detection probability (Pd)
                pd = config.occlusion.pd_outside;
                if ismember(s, config.occlusion.sensors_affected)
                    occ_rect = config.occlusion.rect;
                    if target_pos(1) > occ_rect(1) && target_pos(1) < occ_rect(2) &&...
                       target_pos(2) > occ_rect(3) && target_pos(2) < occ_rect(4)
                        pd = config.occlusion.pd_inside;
                    end
                end

                % Generate detection based on Pd
                if rand < pd
                % if rand < 1.1
                    % Generate noiseless measurement [range; bearing]
                    z_true = [dist_to_sensor; target_bearing];
                    
                    % Add Gaussian noise
                    z_noisy = z_true + chol(config.sensor.R, 'lower') * randn(2, 1);
                    Z_s = [Z_s, z_noisy];
                end
            end
        end

        % --- 2. Generate Clutter ---
        % Determine clutter rate
        % For simplicity, we use a single clutter rate for the whole FoV,
        % but check if the sensor position itself is near the hotspot.
        % A more accurate model would integrate clutter density over the FoV.
        clutter_rate = config.clutter.rate_background;
        if norm(sensor_pos - config.clutter.hotspot_center) < config.clutter.hotspot_radius + config.sensor.max_range
            % If sensor FoV overlaps with hotspot, use a higher average rate
            clutter_rate = (config.clutter.rate_background + config.clutter.rate_hotspot) / 2;
        end
        
        num_clutter = poissrnd(clutter_rate);
        num_clutter = 0;
        % Generate clutter measurements uniformly in the sensor's FoV
        clutter_range = rand(1, num_clutter) * config.sensor.max_range;
        
        if config.sensor.fov(s) == 360
            clutter_bearing = rand(1, num_clutter) * 2 * pi - pi;
        else
            sensor_orientation = atan2(-sensor_pos(2), -sensor_pos(1));
            fov_rad = deg2rad(config.sensor.fov(s));
            clutter_bearing = sensor_orientation + (rand(1, num_clutter) - 0.5) * fov_rad;
        end
        
        clutter_meas = [clutter_range; clutter_bearing];
        
        % Combine true detections and clutter
        Z_s = [Z_s, clutter_meas];
        
        % Randomly shuffle measurements
        measurements_s{s} = Z_s(:, randperm(size(Z_s, 2)));
    end
end