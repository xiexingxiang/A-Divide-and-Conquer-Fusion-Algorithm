%<file path="environment/generate_ground_truth.m">
function [ground_truth_states, ground_truth_card] = generate_ground_truth1(config)
    % Generates ground truth trajectories for multiple targets.
    % Includes CV and CT motion models, birth, and death.
    % Implements pre-defined crossing and parallel maneuvers for challenge.

    sim_steps = config.sim_steps;
    dt = config.dt;

    ground_truth_states = cell(sim_steps, 1);
    ground_truth_card = zeros(sim_steps, 1);

    % Define initial states and maneuvers for 10 targets
    % Format: {id, start_time, end_time, initial_state, model, params}
    % initial_state: [x, vx, y, vy]'
    % model: 'CV' or 'CT'
    % params: for CT, this is the turn rate in rad/s

    maneuvers = {
        % Target 1 & 2: Crossing
        {1, 1, 100, [-2000; 25; 500; 0], 'CV', []},
        {2, 1, 100, [-500; 0; -2000; 25], 'CV', []},

        % Target 3 & 4: Parallel, entering occlusion zone
        {3, 5, 95, [-2000; 20; -200; 0], 'CV', []},
        {4, 5, 95, [-2000; 20; -300; 0], 'CV', []},

        % Target 5: CT maneuver around clutter hotspot
        {5, 10, 100, [-1500; 20; 1000; 0], 'CT', deg2rad(2)},

        % Target 6: Straight path through clutter hotspot
        {6, 15, 85, [-2000; 20; 1500; 0], 'CV', []},

        % Target 7: Enters from top right, CT maneuver
        {7, 20, 100, [2000; -15; 2000; -15], 'CT', deg2rad(-1.5)},

        % Target 8: Born later, simple CV path
        {8, 30, 90, [0; 10; -2000; 20], 'CV', []},

        % Target 9 & 10: Appear and disappear within the simulation
        {9, 1, 50, [-1000; 0; 1800; -15], 'CV', []},
        {10, 40, 80, [1500; -20; -1500; 10], 'CV', []}
    };

    active_targets = {};

    for k = 1:sim_steps
        current_time = k * dt;

        % --- Target Birth ---
        for i = 1:length(maneuvers)
            if maneuvers{i}{2} == k
                target.id = maneuvers{i}{1};
                target.state = maneuvers{i}{4};
                target.model = maneuvers{i}{5};
                target.params = maneuvers{i}{6};
                target.end_time = maneuvers{i}{3};
                active_targets{end+1} = target;
            end
        end

        % --- Target Propagation and Death ---
        next_active_targets = {};
        current_states = [];

        for i = 1:length(active_targets)
            target = active_targets{i};

            % Check for death
        % if k > target.end_time || rand() > config.target.ps
        %    continue; % Target dies
        % end

        % Check for death (deterministic)
        if k > target.end_time
           continue; % Target dies only when its planned lifetime ends
        end

            % Propagate state
            if strcmp(target.model, 'CV')
                target.state = config.target.F_cv * target.state +...
                               chol(config.target.Q_cv, 'lower') * randn(4,1);
            elseif strcmp(target.model, 'CT')
                omega = target.params;
                x = target.state;
                F_ct = [1, sin(omega*dt)/omega, 0, -(1-cos(omega*dt))/omega;
                        0, cos(omega*dt),      0, -sin(omega*dt);
                        0, (1-cos(omega*dt))/omega, 1, sin(omega*dt)/omega;
                        0, sin(omega*dt),      0, cos(omega*dt)];
                target.state = F_ct * x; % Simplified process noise for CT
            end

            % Check if target is within bounds
            if target.state(1) > config.area_x(1) && target.state(1) < config.area_x(2) &&...
               target.state(3) > config.area_y(1) && target.state(3) < config.area_y(2)
                next_active_targets{end+1} = target;
                current_states = [current_states, [target.state(1:4); target.id]];
            end
        end

        active_targets = next_active_targets;

        ground_truth_states{k} = current_states;
        ground_truth_card(k) = size(current_states, 2);
    end
end