% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           REPLACEMENT for evaluation/calculate_track_metrics.m
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [tfr, idsw] = calculate_track_metrics(est_tracks_mc, gt_tracks_mc, config)
    % Calculates Track Fragmentation Rate (TFR) and ID Switches (IDSW)
    % using a frame-by-frame association logic, which is more accurate for these metrics.
    
    sim_steps = config.sim_steps;
    
    % Use containers.Map to store the history of assignments.
    % Key: Ground Truth ID, Value: Cell array of assigned Estimated IDs over time
    gt_to_est_history = containers.Map('KeyType','double','ValueType','any');
    % --- 1. Perform frame-by-frame association ---
    for k = 1:sim_steps
        gt_k = gt_tracks_mc{k};
        est_k = est_tracks_mc{k};
        
        if isempty(gt_k) || isempty(est_k)
            continue; % Nothing to associate in this frame
        end
        
        % Build cost matrix for the current time step
        cost_matrix = pdist2(gt_k(1:2,:)', est_k(1:2,:)');
        
        % Solve assignment for the current frame
        assignment = matchpairs(cost_matrix, config.eval.ospa_c);
        
        % Store the assignment history
        if ~isempty(assignment)
            for i = 1:size(assignment, 1)
                gt_idx = assignment(i, 1);
                est_idx = assignment(i, 2);
                
                gt_id = gt_k(5, gt_idx);
                est_id = est_k(5, est_idx);
                
                if isKey(gt_to_est_history, gt_id)
                    history = gt_to_est_history(gt_id);
                    gt_to_est_history(gt_id) = [history, {est_id}];
                else
                    gt_to_est_history(gt_id) = {{est_id}};
                end
            end
        end
    end
    % --- 2. Calculate TFR from the history ---
    num_fragments = 0;
    tracked_gt_ids = keys(gt_to_est_history);
    num_tracked_gt = length(tracked_gt_ids);
    
    if num_tracked_gt > 0
        for i = 1:num_tracked_gt
            gt_id = tracked_gt_ids{i};
            history = gt_to_est_history(gt_id);
            % The number of fragments is the number of unique estimated IDs
            % that were ever assigned to this ground truth track.
            
            % --- 关键修正: Convert cell to matrix before unique ---
            num_fragments = num_fragments + length(unique(cell2mat([history{:}])));
        end
        % TFR = (Total Fragments - Number of Tracked Truths) / Number of Tracked Truths
        tfr = (num_fragments - num_tracked_gt) / num_tracked_gt;
    else
        tfr = 0;
    end
    % --- 3. Calculate IDSW from the history ---
    % First, build the reverse mapping: est_id -> gt_ids
    est_to_gt_history = containers.Map('KeyType','double','ValueType','any');
    for i = 1:num_tracked_gt
        gt_id = tracked_gt_ids{i};
        history = gt_to_est_history(gt_id);
        
        % --- 关键修正: Convert cell to matrix before unique ---
        unique_est_ids = unique(cell2mat([history{:}]));
        
        for j = 1:length(unique_est_ids)
            est_id = unique_est_ids(j);
            if isKey(est_to_gt_history, est_id)
                rev_history = est_to_gt_history(est_id);
                est_to_gt_history(est_id) = [rev_history, {gt_id}];
            else
                est_to_gt_history(est_id) = {{gt_id}};
            end
        end
    end
    
    idsw = 0;
    tracked_est_ids = keys(est_to_gt_history);
    for i = 1:length(tracked_est_ids)
        est_id = tracked_est_ids{i};
        rev_history = est_to_gt_history(est_id);
        % An ID switch occurs if one estimated track is assigned to more than one ground truth track.
        
        % --- 关键修正: Convert cell to matrix before unique ---
        num_associations = length(unique(cell2mat([rev_history{:}])));
        
        if num_associations > 1
            idsw = idsw + (num_associations - 1);
        end
    end
end