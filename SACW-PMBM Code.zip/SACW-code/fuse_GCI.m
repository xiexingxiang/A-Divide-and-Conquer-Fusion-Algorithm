function fused_pmbm = fuse_GCI(local_pmbms, config)
num_sensors = length(local_pmbms);
    fused_pmbm.ppp.w = 0;
    fused_pmbm.MBM = {};
    
    % Collect all unique tracks from local filters' best hypotheses
    track_pool = containers.Map('KeyType','double','ValueType','any');
    for s = 1:num_sensors
        if ~isempty(local_pmbms{s}.MBM)
            [~, best_h_idx] = max([local_pmbms{s}.MBM{:}.w]); % <--- 修正
            local_best_hyp = local_pmbms{s}.MBM{best_h_idx};
            if isfield(local_best_hyp, 'tracks')
                for i = 1:length(local_best_hyp.tracks)
                    track = local_best_hyp.tracks{i};
                    if ~isKey(track_pool, track.id)
                        track_pool(track.id) = {track};
                    else
                        existing_tracks = track_pool(track.id);
                        track_pool(track.id) = [existing_tracks, {track}];
                    end
                end
            end
        end
    end
    
    % Fuse each unique track using SACW
    fused_tracks = {};
    all_ids = keys(track_pool);
    for i = 1:length(all_ids)
        id = all_ids{i};
        tracks_to_fuse = track_pool(id);
        
        % Get the mean state to calculate weights
        mean_pos = tracks_to_fuse{1}.m([1, 3]);
        
        [idx_min_sensor,weights] = calculate_gci_weights(mean_pos, local_pmbms, config);
        
        % Perform GCI-like fusion with these adaptive weights
        P_inv_fused = zeros(4,4);
        m_P_inv_fused = zeros(4,1);

        r_fused = 0;
        for j = 1:length(local_pmbms)
            if idx_min_sensor(j) ~= 0
                P_inv = inv(local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.P);
                P_inv_fused = P_inv_fused + weights(j) * P_inv;
                m_P_inv_fused = m_P_inv_fused + weights(j) * P_inv * local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.m;
                if local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.r > r_fused
                    r_fused = local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.r;
                end
                % r_fused = r_fused + (local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.r * weights(j));
            end
        end

        fused_track.P = inv(P_inv_fused);
        fused_track.m = fused_track.P * m_P_inv_fused;
        fused_track.r = r_fused;
        fused_track.id = id;
        fused_tracks{end+1} = fused_track;
    end
    
    if ~isempty(fused_tracks)
        fused_pmbm.MBM{1}.w = 1.0;
        fused_pmbm.MBM{1}.tracks = fused_tracks;
        fused_pmbm.MBM{1}.id_counter = max([all_ids{:}]);
    end

    % --- 2. Fuse PPP component ---
    % This requires integrating over the entire state space, which is complex.
    % We approximate by using the average weights.
    avg_weights = ones(1, num_sensors) / num_sensors; % Fallback to average
    fused_intensity = 0;
    for s = 1:num_sensors
        fused_intensity = fused_intensity + avg_weights(s) * exp(local_pmbms{s}.ppp.w);
    end
    fused_pmbm.ppp.w = log(fused_intensity);
end



%     % Fuses local PMBM posteriors using Generalized Covariance Intersection (GCI)
%     num_sensors = length(local_pmbms);
% 
%     % Handle missing weights
%     if nargin < 2 || isempty(weights)
%         weights = ones(1, num_sensors) / num_sensors;
%     end
% 
%     % Initialize fused PMBM
%     fused_pmbm.ppp.w = 0;
%     fused_pmbm.MBM = {};
% 
%     % --- 1. Fuse PPP component using GCI (log-linear pooling) ---
%     fused_log_intensity = 0;
%     for s = 1:num_sensors
%         fused_log_intensity = fused_log_intensity + weights(s) * local_pmbms{s}.ppp.w;
%     end
%     fused_pmbm.ppp.w = fused_log_intensity;
% 
%     % --- 2. Fuse MBM component ---
%     % Collect best hypothesis from each sensor
%     best_hypotheses = cell(1, num_sensors);
%     for s = 1:num_sensors
%         if ~isempty(local_pmbms{s}.MBM)
%             [~, best_idx] = max([local_pmbms{s}.MBM{:}.w]);
%             best_hypotheses{s} = local_pmbms{s}.MBM{best_idx};
%         else
%             best_hypotheses{s} = struct('tracks', {}, 'w', []);
%         end
%     end
% 
%     % Create track pool: map(id -> list of tracks from different sensors)
%     track_pool = containers.Map('KeyType', 'double', 'ValueType', 'any');
%     for s = 1:num_sensors
%         if isfield(best_hypotheses{s}, 'tracks')
%             if ~isempty(best_hypotheses{s})
%                 for j = 1:length(best_hypotheses{s}.tracks)
%                     track = best_hypotheses{s}.tracks{j};
%                     if isKey(track_pool, track.id)
%                         track_list = track_pool(track.id);
%                         track_list{end+1} = struct('sensor', s, 'track', track);
%                         track_pool(track.id) = track_list;
%                     else
%                         track_pool(track.id) = {{struct('sensor', s, 'track', track)}};
%                     end
%                 end
%             end
%         end
%     end
% 
%     % Fuse tracks using GCI
%     fused_tracks = {};
%     all_ids = keys(track_pool);
%     for i = 1:length(all_ids)
%         id = all_ids{i};
%         track_list = track_pool(id);
%         num_tracks = length(track_list);
% 
%         % Extract states and existence probabilities
%         states = cell(1, num_tracks);
%         covariances = cell(1, num_tracks);
%         rs = zeros(1, num_tracks);
%         sensor_weights = zeros(1, num_tracks);
% 
%         % Calculate adaptive weights if needed
%         if 0
%             avg_pos = zeros(2, 1);
%             for k = 1:num_tracks
%                 m = track_list{k}.track.m;
%                 avg_pos = avg_pos + [m(1); m(3)]; % Extract position
%             end
%             avg_pos = avg_pos / num_tracks;
%             sensor_weights_all = calculate_gci_weights(avg_pos, config);
%         end
% 
%         for k = 1:num_tracks
%             track_data = track_list{k};
%             states{k} = track_data.track.m;
%             covariances{k} = track_data.track.P;
%             rs(k) = track_data.track.r;
% 
%             if config.gci.use_adaptive_weights
%                 sensor_weights(k) = sensor_weights_all(track_data.sensor);
%             else
%                 sensor_weights(k) = weights(track_data.sensor);
%             end
%         end
% 
%         % Normalize weights for this track
%         total_weight = sum(sensor_weights);
%         if total_weight > 0
%             sensor_weights = sensor_weights / total_weight;
%         else
%             sensor_weights = ones(1, num_tracks) / num_tracks;
%         end
% 
%         % Fuse existence probability (log-linear pooling)
%         log_r_sum = 0;
%         log_not_r_sum = 0;
%         for k = 1:num_tracks
%             w = sensor_weights(k);
%             log_r_sum = log_r_sum + w * log(rs(k));
%             log_not_r_sum = log_not_r_sum + w * log(1 - rs(k));
%         end
%         r_fused = exp(log_r_sum) / (exp(log_r_sum) + exp(log_not_r_sum));
% 
%         % Fuse state estimates using GCI
%         P_inv_sum = zeros(size(covariances{1}));
%         weighted_sum = zeros(size(states{1}));
%         for k = 1:num_tracks
%             w = sensor_weights(k);
%             P_inv = inv(covariances{k});
%             P_inv_sum = P_inv_sum + w * P_inv;
%             weighted_sum = weighted_sum + w * P_inv * states{k};
%         end
% 
%         P_fused = inv(P_inv_sum);
%         m_fused = P_fused * weighted_sum;
% 
%         % Create fused track
%         fused_track = struct();
%         fused_track.id = id;
%         fused_track.r = r_fused;
%         fused_track.m = m_fused;
%         fused_track.P = P_fused;
%         fused_tracks{end+1} = fused_track;
%     end
% 
%     % Create fused MBM hypothesis
%     if ~isempty(fused_tracks)
%         fused_hypo.w = 1.0;
%         fused_hypo.tracks = fused_tracks;
%         fused_hypo.id_counter = max([all_ids{:}]);
%         fused_pmbm.MBM = {fused_hypo};
%     end
% end
% 
% % function fused_pmbm = fuse_GCI(local_pmbms, config)
% %     % Fuses local PMBM posteriors using Generalized Covariance Intersection (GCI)
% %     num_sensors = length(local_pmbms);
% %     fused_pmbm.ppp.w = 0;
% %     fused_pmbm.MBM = {};
% % 
% %     % ===== 1. Fuse PPP component (Geometric Average) =====
% %     weights_ppp = ones(1, num_sensors) / num_sensors;  % Uniform weights for PPP
% %     fused_log_intensity = 0;
% %     for s = 1:num_sensors
% %         fused_log_intensity = fused_log_intensity + weights_ppp(s) * local_pmbms{s}.ppp.w;
% %     end
% %     fused_pmbm.ppp.w = fused_log_intensity;  % Log-intensity after geometric averaging
% % 
% %     % ===== 2. Fuse MBM component =====
% %     % Step 2.1: Collect all tracks from best hypotheses
% %     all_tracks = [];
% %     for s = 1:num_sensors
% %         if ~isempty(local_pmbms{s}.MBM)
% %             [~, best_idx] = max([local_pmbms{s}.MBM{:}.w]);
% %             best_hyp = local_pmbms{s}.MBM{best_idx};
% %             for t = 1:length(best_hyp.tracks)
% %                 track = best_hyp.tracks{t};
% %                 track.sensor_idx = s;  % Tag with sensor index
% %                 all_tracks = [all_tracks; track];
% %             end
% %         end
% %     end
% % 
% %     % Step 2.2: Cluster tracks by position
% %     cluster_threshold = config.gating_threshold;  % Typically 50-100 meters
% %     fused_tracks = {};
% %     while ~isempty(all_tracks)
% %         seed = all_tracks(1);
% %         seed_pos = seed.m([1, 3]);
% %         cluster = seed;
% %         cluster_sensors = seed.sensor_idx;
% %         all_tracks(1) = [];
% % 
% %         % Find matching tracks
% %         i = 1;
% %         while i <= length(all_tracks)
% %             track = all_tracks(i);
% %             track_pos = track.m([1, 3]);
% %             if norm(seed_pos - track_pos) < cluster_threshold
% %                 cluster = [cluster; track];
% %                 cluster_sensors = [cluster_sensors; track.sensor_idx];
% %                 all_tracks(i) = [];
% %             else
% %                 i = i + 1;
% %             end
% %         end
% % 
% %         % Step 2.3: Calculate adaptive weights for this cluster
% %         cluster_center = mean(cell2mat(cellfun(@(t) t.m([1, 3])', ...
% %             num2cell(cluster), 'UniformOutput', false)), 1);
% %         weights = calculate_gci_weights(cluster_center, local_pmbms, config);
% % 
% %         % Step 2.4: GCI fusion for this cluster
% %         P_inv = zeros(4);
% %         P_inv_m = zeros(4, 1);
% %         r_logit = 0;
% % 
% %         for j = 1:length(cluster)
% %             track = cluster(j);
% %             s_idx = cluster_sensors(j);
% %             w = weights(s_idx);
% % 
% %             % State fusion
% %             P_inv_j = inv(track.P);
% %             P_inv = P_inv + w * P_inv_j;
% %             P_inv_m = P_inv_m + w * P_inv_j * track.m;
% % 
% %             % Existence probability fusion
% %             r_j = max(min(track.r, 1-1e-6), 1e-6);  % Avoid log(0)
% %             r_logit = r_logit + w * log(r_j / (1 - r_j));
% %         end
% % 
% %         % Create fused track
% %         fused_track = struct();
% %         fused_track.P = inv(P_inv);
% %         fused_track.m = fused_track.P * P_inv_m;
% %         fused_track.r = 1 / (1 + exp(-r_logit));  % Logistic inverse
% %         fused_track.id = seed.id;  % Preserve original ID
% % 
% %         fused_tracks{end+1} = fused_track;
% %     end
% % 
% %     % Step 2.5: Build fused MBM
% %     if ~isempty(fused_tracks)
% %         fused_pmbm.MBM{1}.w = 1.0;
% %         fused_pmbm.MBM{1}.tracks = fused_tracks;
% %         fused_pmbm.MBM{1}.id_counter = max(cellfun(@(t) t.id, fused_tracks));
% %     end
% % end
% % 
% % 
% % % %<file path="components/fuse_GCI.m">
% % % function fused_pmbm = fuse_GCI(local_pmbms, weights, config)
% % %     % Fuses local PMBM posteriors using Generalized Covariance Intersection (GCI).
% % %     % This is a simplified implementation.
% % % 
% % %     num_sensors = length(local_pmbms);
% % %     fused_pmbm.ppp.w = 0;
% % %     fused_pmbm.MBM = {};
% % % 
% % %     % --- 1. Fuse PPP component (Geometric Average) ---
% % %     fused_log_intensity = 0;
% % %     for s = 1:num_sensors
% % %         fused_log_intensity = fused_log_intensity + weights(s) * local_pmbms{s}.ppp.w;
% % %     end
% % %     fused_pmbm.ppp.w = fused_log_intensity; % Normalization constant ignored for uniform
% % % 
% % %     % --- 2. Fuse MBM component (Geometric Average) ---
% % %     % GCI fusion of MBMs is extremely complex due to hypothesis matching.
% % %     % We simplify by performing GCI on individual tracks that are matched across sensors.
% % % 
% % %     % First, collect all unique tracks from all local filters' best hypotheses.
% % %     track_pool = containers.Map('KeyType','double','ValueType','any');
% % %     for s = 1:num_sensors
% % %         if ~isempty(local_pmbms{s}.MBM)
% % %             [~, best_h_idx] = max([local_pmbms{s}.MBM{:}.w]); % <--- 修正
% % %             local_best_hyp = local_pmbms{s}.MBM{best_h_idx};
% % %             if isfield(local_best_hyp, 'tracks')
% % %                 for i = 1:length(local_best_hyp.tracks)
% % %                     track = local_best_hyp.tracks{i};
% % %                     if ~isKey(track_pool, track.id)
% % %                         track_pool(track.id) = {track};
% % %                     else
% % %                         existing_tracks = track_pool(track.id);
% % %                         track_pool(track.id) = [existing_tracks, {track}];
% % %                     end
% % %                 end
% % %             end
% % %         end
% % %     end
% % % 
% % %     % Now, for each unique track ID, fuse the corresponding tracks
% % %     fused_tracks = {};
% % %     all_ids = keys(track_pool);
% % %     for i = 1:length(all_ids)
% % %         id = all_ids{i};
% % %         tracks_to_fuse = track_pool(id);
% % % 
% % %         if length(tracks_to_fuse) == 1
% % %             fused_tracks{end+1} = tracks_to_fuse{1};
% % %             continue;
% % %         end
% % % 
% % %         % GCI fusion for a single Gaussian
% % %         P_inv_fused = zeros(4,4);
% % %         m_P_inv_fused = zeros(4,1);
% % %         r_fused = 1;
% % % 
% % %         for j = 1:length(tracks_to_fuse)
% % %             P_inv = inv(tracks_to_fuse{j}.P);
% % %             P_inv_fused = P_inv_fused + weights(j) * P_inv;
% % %             m_P_inv_fused = m_P_inv_fused + weights(j) * P_inv * tracks_to_fuse{j}.m;
% % %             r_fused = r_fused * (tracks_to_fuse{j}.r ^ weights(j));
% % %         end
% % % 
% % %         fused_track.P = inv(P_inv_fused);
% % %         fused_track.m = fused_track.P * m_P_inv_fused;
% % %         fused_track.r = r_fused;
% % %         fused_track.id = id;
% % %         fused_tracks{end+1} = fused_track;
% % %     end
% % % 
% % %     if ~isempty(fused_tracks)
% % %         fused_pmbm.MBM{1}.w = 1.0;
% % %         fused_pmbm.MBM{1}.tracks = fused_tracks;
% % %         fused_pmbm.MBM{1}.id_counter = max([all_ids{:}]);
% % %     end
% % % end