%<file path="filters/run_GCI_PMBM.m">
function [estimated_tracks, estimated_card] = run_GCI_PMBM(all_measurements, config,ground_truth_states)
% Runs the Distributed PMBM filter with Generalized Covariance Intersection (GCI) fusion.

if config.filter.plot_tra
    % --- Plot Ground Truth Trajectories ---
    figure;
    hold on;
    title('Ground Truth Trajectories');
    xlabel('X Position');
    ylabel('Y Position');
    for t = 1:config.sim_steps
        % Extract the states for the current time step
        states = ground_truth_states{t};
        % Plot each target's trajectory
        for target_idx = 1:size(states, 2)
            plot(states(1, target_idx), states(3, target_idx), 'o', 'MarkerSize', 1, 'Color',"b");
        end
    end
    grid on;
end

sim_steps = config.sim_steps;
num_sensors = config.sensor.num_sensors;
estimated_tracks = cell(sim_steps, 1);
estimated_card = zeros(sim_steps, 1);

% Initialize local PMBM filters
local_pmbms = cell(num_sensors, 1);
for s = 1:num_sensors
    local_pmbms{s}.ppp.w = log(config.filter.birth_intensity_uniform);
    local_pmbms{s}.ppp.m = [];
    local_pmbms{s}.ppp.P = [];
    local_pmbms{s}.MBM = {};
end

for k = 1:sim_steps
    % 1. Local PMBM Prediction and Update
    for s = 1:num_sensors
        local_pmbms{s} = pmbm_predict_step(local_pmbms{s}, config);
        Zk_s = all_measurements{k}{s};
        sensor_model_s.p_d = config.filter.p_d;
        sensor_model_s.clutter_rate = config.clutter.rate_background;
        sensor_model_s.pos = config.sensor.positions(s,:);
        sensor_model_s.R = config.sensor.R;
        sensor_model_s.id = s; % <--- 在这里添加
        local_pmbms{s} = c_pmbm_update_step(local_pmbms{s}, Zk_s, sensor_model_s, config);
        local_pmbms{s} = prune_and_merge(local_pmbms{s}, config);
        if config.filter.plot_tra
            estimated_states1 = pmbm_extract_state(local_pmbms{s}, config);
            if ~isempty(estimated_states1)
                states = estimated_states1;
                % Plot each target's trajectory
                for target_idx = 1:size(states, 2)
                    plot(states(1, target_idx), states(3, target_idx), '*', 'MarkerSize', 3, 'Color',"g");
                    hold on
                end
            end
        end
    end
    % 2. Fusion Step
    fused_pmbm = fuse_GCI(local_pmbms, config);

    % 3. Pruning and Merging
    fused_pmbm = prune_and_merge(fused_pmbm, config);

    % 4. State Extraction
    estimated_states = pmbm_extract_state(fused_pmbm, config); % <--- 修正
    if config.filter.plot_tra
        if ~isempty(estimated_states)
            states = estimated_states;
            % Plot each target's trajectory
            for target_idx = 1:size(states, 2)
                plot(states(1, target_idx), states(3, target_idx), '+', 'MarkerSize', 6,'Color',"r");
                hold on
            end
        end
    end
    estimated_tracks{k} = estimated_states;
    estimated_card(k) = size(estimated_states, 2);

    % 5. Feedback
    for s = 1:num_sensors
        local_pmbms{s} = fused_pmbm;
    end
end
end