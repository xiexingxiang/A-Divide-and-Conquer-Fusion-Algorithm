%<file path="components/calculate_confidence_weights.m">
function [idx_min_sensor,weights] = calculate_waa_weights(target_pos, local_pmbms, config)
    
    num_sensors = config.sensor.num_sensors;
    weights_unnormalized = zeros(1, num_sensors);
    
    for s = 1:num_sensors
 
        idx_min = [];
        if ~isempty(local_pmbms{s}.MBM) && isfield(local_pmbms{s}.MBM{1}, 'tracks')
            min_dist = inf;
            best_P = [];
            for i = 1:length(local_pmbms{s}.MBM{1}.tracks)
                dist = norm(target_pos - local_pmbms{s}.MBM{1}.tracks{i}.m([1, 3]));
                if dist < min_dist
                    min_dist = dist;
                    best_P = local_pmbms{s}.MBM{1}.tracks{i}.P;
                    idx_min = i;
                end
            end
            if ~isempty(best_P)
                if min_dist>config.filter.waa_multi_merging_threshold
                    idx_min=0;
                end
            end
        end
        weights_unnormalized(s) = 1;
        if isempty(idx_min)
            idx_min_sensor(s) = 0;
        else
        idx_min_sensor(s) = idx_min;
        end
    end
    
    % Normalize weights to sum to 1
    weights_unnormalized(~idx_min_sensor) = 0;
    total_weight = sum(weights_unnormalized);
    if total_weight > 0
        weights = weights_unnormalized / total_weight;
    else
        weights = ones(1, num_sensors) / num_sensors; % Fallback
    end
end