%<file path="components/pmbm_extract_state.m">
function estimated_states = pmbm_extract_state(pmbm, config) % <--- 修正
%function [estimated_states, MBM_out] = pmbm_extract_state(pmbm, config) % <--- 修正
    % Extracts the most likely set of target states from the PMBM posterior.
    % Also assigns/updates track IDs.
    
    estimated_states = [];
    MBM_out = pmbm.MBM;

    if isempty(pmbm.MBM)
        return;
    end

    % Find the global hypothesis with the highest weight
    max_w = -inf;
    best_h_idx = -1;
    for h = 1:length(pmbm.MBM)
        if pmbm.MBM{h}.w > max_w
            max_w = pmbm.MBM{h}.w;
            best_h_idx = h;
        end
    end

    if best_h_idx == -1
        return;
    end
    
    best_hypothesis = pmbm.MBM{best_h_idx};
    
    % Extract states from Bernoulli components with existence prob > 0.5
    if ~isfield(best_hypothesis, 'tracks') || isempty(best_hypothesis.tracks)
       return;
    end


    if ~isfield(best_hypothesis, 'id_counter')
        best_hypothesis.id_counter = 0;
    end

    next_tracks = {};
    for i = 1:length(best_hypothesis.tracks)
        track = best_hypothesis.tracks{i};
        if track.r > 0.5
            if ~isfield(track, 'id') || isempty(track.id)
                best_hypothesis.id_counter = best_hypothesis.id_counter + 1;
                track.id = best_hypothesis.id_counter;
            end
  
            % State format: [x, vx, y, vy, id]'
            est_state = [track.m; track.id];
            estimated_states = [estimated_states, est_state];
        end
        % Keep track for next iteration even if not extracted
        next_tracks{end+1} = track;
    end
    
    % Update the MBM with the potentially new IDs
    MBM_out{best_h_idx}.tracks = next_tracks;
    MBM_out{best_h_idx}.id_counter = best_hypothesis.id_counter;
end