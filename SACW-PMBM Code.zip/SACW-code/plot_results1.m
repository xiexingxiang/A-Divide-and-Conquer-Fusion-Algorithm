% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           FINAL REPLACEMENT for plotting/plot_results.m
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plot_results1(results, config)
    % Generates all plots and tables for the simulation results.
    
    algorithms = {'SACW_PMBM', 'C_PMBM', 'WAA_PMBM', 'GCI_PMBM'};
    alg_names = {'SACW-PMBM', 'C-PMBM', 'WAA-PMBM', 'GCI-PMBM'};
    colors = {'g', 'b', 'r', 'm'};
    line_styles = {'-', '--', ':', '-.'};
    
    % --- Calculate Averages ---
    avg_results = struct();
    for i = 1:length(algorithms)
        alg = algorithms{i};
        avg_results.(alg).ospa = nanmean(results.(alg).ospa, 2);
        avg_results.(alg).gospa = nanmean(results.(alg).gospa, 2);
        avg_results.(alg).rmse = nanmean(results.(alg).rmse, 2);
        avg_results.(alg).card_est = nanmean(results.(alg).card_est, 2);
    end
    avg_results.card_true = nanmean(results.SACW_PMBM.card_true, 2);
    
    time_vector = (1:config.sim_steps) * config.dt;
    
    %% --- Figure 1: OSPA, GOSPA, RMSE vs. Time ---
    figure('Name', 'Estimation Errors vs. Time', 'Position', [100, 100, 1500, 400]);
    
    % OSPA
    subplot(1,3,1);
    hold on; box on;
    for i = 1:length(algorithms)
        plot(time_vector, avg_results.(algorithms{i}).ospa, 'Color', colors{i}, 'LineStyle', line_styles{i}, 'LineWidth', 1.5, 'DisplayName', alg_names{i});
    end
    title('(a) OSPA Error');
    xlabel('Time (s)');
    ylabel('OSPA (m)');
    legend('Location', 'northwest', 'Interpreter', 'none');
    grid on;
    pbaspect([1 1 1]);
    % GOSPA
    subplot(1,3,2);
    hold on; box on;
    for i = 1:length(algorithms)
        plot(time_vector, avg_results.(algorithms{i}).gospa, 'Color', colors{i}, 'LineStyle', line_styles{i}, 'LineWidth', 1.5, 'DisplayName', alg_names{i});
    end
    title('(b) GOSPA Error');
    xlabel('Time (s)');
    ylabel('GOSPA (m)');
    legend('Location', 'northwest', 'Interpreter', 'none');
    grid on;
    pbaspect([1 1 1]);
    % RMSE
    subplot(1,3,3);
    hold on; box on;
    for i = 1:length(algorithms)
        plot(time_vector, avg_results.(algorithms{i}).rmse, 'Color', colors{i}, 'LineStyle', line_styles{i}, 'LineWidth', 1.5, 'DisplayName', alg_names{i});
    end
    title('(c) RMSE (for matched tracks)');
    xlabel('Time (s)');
    ylabel('RMSE (m)');
    legend('Location', 'northwest', 'Interpreter', 'none');
    grid on;
    pbaspect([1 1 1]);
    %% --- Figure 2: Cardinality Estimation vs. Time ---
    figure('Name', 'Cardinality Estimation');
    hold on; box on;
    plot(time_vector, avg_results.card_true, 'k-', 'LineWidth', 2, 'DisplayName', 'Ground Truth');
    for i = 1:length(algorithms)
        plot(time_vector, avg_results.(algorithms{i}).card_est, 'Color', colors{i}, 'LineStyle', line_styles{i}, 'LineWidth', 1.5, 'DisplayName', alg_names{i});
    end
    title('Estimated Number of Targets');
    xlabel('Time (s)');
    ylabel('Number of Targets');
    legend('Location', 'best', 'Interpreter', 'none');
    grid on;
    
    %% --- Figure 3 & Table 2: Track Quality Metrics (TFR, IDSW) ---
    tfr_vals = zeros(1, length(algorithms));
    idsw_vals = zeros(1, length(algorithms));
    
    for i = 1:length(algorithms)
        alg = algorithms{i};
        tfr_mc = zeros(1, config.num_mc_runs);
        idsw_mc = zeros(1, config.num_mc_runs);
        for mc = 1:config.num_mc_runs
            [tfr_mc(mc), idsw_mc(mc)] = calculate_track_metrics(results.(alg).tracks{mc}, results.(alg).ground_truth{mc}, config);
        end
        tfr_vals(i) = mean(tfr_mc);
        idsw_vals(i) = sum(idsw_mc);
    end
    
    figure('Name', 'Track Quality Metrics');
    subplot(1,2,1);
    bar(tfr_vals);
    set(gca, 'XTickLabel', alg_names, 'TickLabelInterpreter', 'none');
    title('Track Fragmentation Rate (TFR)');
    ylabel('Fragments per True Track');
    grid on; box on;
  
    
    subplot(1,2,2);
    bar(idsw_vals);
    set(gca, 'XTickLabel', alg_names, 'TickLabelInterpreter', 'none');
    title('ID Switches (IDSW)');
    ylabel('Total Switches');
    grid on; box on;
   
     %% --- Figure 4: Trajectory Plot ---
    figure('Name', 'Ground Truth vs. Estimated Trajectories');
    hold on; box on;
    mc_run_to_plot = 1;
    
    plot_trajectories(results, config, algorithms, colors, line_styles, mc_run_to_plot);
    
    % 修改这里：传入算法参数给图例函数
    plot_scenario_and_legend(config, algorithms, colors, line_styles, alg_names, true, true); % include_occlusion = true, include_algorithms = true
    
    title('Simulated Experimental Scenario');
    xlabel('X (m)');
    ylabel('Y (m)');
    axis([config.area_x config.area_y]);
    grid on; hold on; box on;

    %% --- Figure 5: Trajectory Plot (No Occlusion Zone) ---
    figure('Name', 'Ground Truth vs. Estimated Trajectories (No Occlusion Zone)');
    hold on; box on;
    
    plot_trajectories(results, config, algorithms, colors, line_styles, mc_run_to_plot);
    
    % Call the scenario and legend plotting function, indicating NOT to include occlusion
    plot_scenario_and_legend(config, algorithms, colors, line_styles, alg_names, false, true); % include_occlusion = false, include_algorithms = true
    
    title('Simulated Experimental Scenario (No Occlusion Zone)');
    xlabel('X (m)');
    ylabel('Y (m)');
    axis([config.area_x config.area_y]);
    grid on; hold on; box on;

    %% --- Figure 6: Ground Truth Trajectories Only ---
    figure('Name', 'Ground Truth Trajectories');
    hold on; box on;
    
    % Plot only ground truth trajectories using the helper function
    plot_ground_truth_only_trajectories(results, config, mc_run_to_plot);

    % Plot scenario and legend without estimated trajectories and without algorithm legend entries
    plot_scenario_and_legend(config, algorithms, colors, line_styles, alg_names, true, false); % include_occlusion = true, include_algorithms = false
    
    title('Simulated Experimental Scenario'); % Title similar to the provided image
    xlabel('X (m)');
    ylabel('Y (m)');
    axis([config.area_x config.area_y]);
    grid on; hold on; box on;
   
    % --- Tables ---
    print_tables(results, avg_results, algorithms, alg_names, tfr_vals, idsw_vals);
    
end
% --- Helper Functions for plotting ---
function plot_trajectories(results, config, algorithms, colors, line_styles, mc)
    % Plot ground truth
    gt_tracks = results.SACW_PMBM.ground_truth{mc};
    if ~isempty(gt_tracks)
        gt_matrix = [gt_tracks{:}];
        if ~isempty(gt_matrix)
            gt_ids = unique(gt_matrix(5,:));
            for id = gt_ids
                x_traj = []; y_traj = [];
                for k = 1:config.sim_steps
                    if ~isempty(gt_tracks{k})
                        idx = find(gt_tracks{k}(5,:) == id, 1);
                        if ~isempty(idx)
                            x_traj = [x_traj, gt_tracks{k}(1,idx)];
                            y_traj = [y_traj, gt_tracks{k}(3,idx)];
                        end
                    end
                end
                plot(x_traj, y_traj, 'k-', 'LineWidth', 2.5, 'HandleVisibility', 'off');
                
                if ~isempty(x_traj)
                    plot(x_traj(1), y_traj(1), 'o', 'Color', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 8, 'HandleVisibility', 'off');
                    plot(x_traj(end), y_traj(end), 'x', 'Color', 'r', 'MarkerSize', 10, 'LineWidth', 2.5, 'HandleVisibility', 'off');
                    
            
                    text(x_traj(1) + 80, y_traj(1) + 80, num2str(id), 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
                end
            end
        end
    end
    % Plot estimated tracks
    for i = 1:length(algorithms)
        alg = algorithms{i};
        est_tracks = results.(alg).tracks{mc};
        if ~isempty(est_tracks)
            est_matrix = [est_tracks{:}];
            if ~isempty(est_matrix)
                est_ids = unique(est_matrix(5,:));
                for id = est_ids
                   x_traj = []; y_traj = [];
                    for k = 1:config.sim_steps
                        if ~isempty(est_tracks{k})
                            idx = find(est_tracks{k}(5,:) == id, 1);
                            if ~isempty(idx)
                                x_traj = [x_traj, est_tracks{k}(1,idx)];
                                y_traj = [y_traj, est_tracks{k}(3,idx)];
                            end
                        end
                    end
                   plot(x_traj, y_traj, 'Color', colors{i}, 'LineStyle', line_styles{i}, 'LineWidth', 1.5, 'HandleVisibility', 'off');
                end
            end
        end
    end
end

function plot_ground_truth_only_trajectories(results, config, mc)
    % Plot ground truth
    gt_tracks = results.SACW_PMBM.ground_truth{mc};
    if ~isempty(gt_tracks)
        gt_matrix = [gt_tracks{:}];
        if ~isempty(gt_matrix)
            gt_ids = unique(gt_matrix(5,:));
            for id = gt_ids
                x_traj = []; y_traj = [];
                for k = 1:config.sim_steps
                    if ~isempty(gt_tracks{k})
                        idx = find(gt_tracks{k}(5,:) == id, 1);
                        if ~isempty(idx)
                            x_traj = [x_traj, gt_tracks{k}(1,idx)];
                            y_traj = [y_traj, gt_tracks{k}(3,idx)];
                        end
                    end
                end
                plot(x_traj, y_traj, 'k-', 'LineWidth', 2.5, 'HandleVisibility', 'off');
                
                if ~isempty(x_traj)
                    plot(x_traj(1), y_traj(1), 'o', 'Color', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 8, 'HandleVisibility', 'off');
                    plot(x_traj(end), y_traj(end), 'x', 'Color', 'r', 'MarkerSize', 10, 'LineWidth', 2.5, 'HandleVisibility', 'off');
                    
                    text(x_traj(1) + 80, y_traj(1) + 80, num2str(id), 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
                end
            end
        end
    end
    % No estimated tracks are plotted in this function
end


function plot_scenario_and_legend(config, algorithms, colors, line_styles, alg_names, include_occlusion, include_algorithms) % Added include_algorithms flag
    % 1. 绘制场景特征
    if include_occlusion
        rectangle('Position', [config.occlusion.rect(1), config.occlusion.rect(3),...
            config.occlusion.rect(2)-config.occlusion.rect(1), config.occlusion.rect(4)-config.occlusion.rect(3)],...
            'FaceColor', [1 0.8 0.8 0.3], 'EdgeColor', 'none');
    end
    viscircles(config.clutter.hotspot_center, config.clutter.hotspot_radius, 'Color', [0.5  0  0.5], 'LineStyle', '--');
    plot(config.sensor.positions(:,1), config.sensor.positions(:,2), 'k^', 'MarkerSize', 10, 'MarkerFaceColor', 'y', 'HandleVisibility', 'off');
    
    % 2. 创建场景图例项
    num_scenario_items = 4; % Ground Truth, Start, End, Sensors, Clutter Hotspot
    if include_occlusion
        num_scenario_items = num_scenario_items + 1; % Add Occlusion Zone
    end
    if include_algorithms
        num_scenario_items = num_scenario_items + length(algorithms);
    end

    h = gobjects(num_scenario_items, 1); 
    
    % Scenario legend items
    h_idx = 1;
    h(h_idx) = plot(NaN, NaN, 'k-', 'LineWidth', 2.5, 'DisplayName', 'Ground Truth'); h_idx = h_idx + 1;
    h(h_idx) = plot(NaN, NaN, 'o', 'Color', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 8, 'DisplayName', 'Start'); h_idx = h_idx + 1;
    h(h_idx) = plot(NaN, NaN, 'x', 'Color', 'r', 'MarkerSize', 10, 'LineWidth', 2.5, 'DisplayName', 'End'); h_idx = h_idx + 1;
    h(h_idx) = plot(NaN, NaN, 'k^', 'MarkerSize', 10, 'MarkerFaceColor', 'y', 'DisplayName', 'Sensors'); h_idx = h_idx + 1;
    if include_occlusion
        h(h_idx) = fill(NaN, NaN, [1 0.8 0.8], 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'DisplayName', 'Occlusion Zone'); h_idx = h_idx + 1;
    end
    h(h_idx) = plot(NaN, NaN, '--', 'Color', [0.5  0  0.5], 'LineWidth', 1.5, 'DisplayName', 'Clutter Hotspot'); h_idx = h_idx + 1;
    
    % 3. Add algorithm legend items (conditionally)
    if include_algorithms
        for i = 1:length(algorithms)
            h(h_idx) = plot(NaN, NaN, ...
                'Color', colors{i}, ...
                'LineStyle', line_styles{i}, ...
                'LineWidth', 1.5, ...
                'DisplayName', alg_names{i});
            h_idx = h_idx + 1;
        end
    end

    % 4. Create legend (automatically exclude invalid handles)
    valid_handles = h(isgraphics(h));
    legend(valid_handles, ...
        'Location', 'best', ...
        'Interpreter', 'none', ...
        'NumColumns', 2);
end
function print_tables(results, avg_results, algorithms, alg_names, tfr_vals, idsw_vals)
    % --- Table 1: Quantitative Error Comparison ---
    fprintf('\n--- Table 1: Average Estimation Errors ---\n');
    fprintf('%-12s | %-15s | %-15s | %-15s\n', 'Algorithm', 'OSPA (m)', 'GOSPA (m)', 'RMSE (m)');
    fprintf('----------------------------------------------------------------\n');
    for i = 1:length(algorithms)
        alg = algorithms{i};
        fprintf('%-12s | %-15.2f | %-15.2f | %-15.2f\n',...
            alg_names{i},...
            mean(avg_results.(alg).ospa),...
            mean(avg_results.(alg).gospa),...
            nanmean(avg_results.(alg).rmse));
    end
    
    % --- Table 2: Quantitative Track Quality Comparison ---
    card_rmse = zeros(1, length(algorithms));
    for i = 1:length(algorithms)
        alg = algorithms{i};
        card_err = results.(alg).card_est - results.SACW_PMBM.card_true;
        card_rmse(i) = sqrt(mean(card_err(:).^2));
    end
    
    fprintf('\n--- Table 2: Track Quality Metrics ---\n');
    fprintf('%-12s | %-15s | %-15s | %-15s\n', 'Algorithm', 'Card. RMSE', 'TFR', 'IDSW');
    fprintf('----------------------------------------------------------------\n');
    for i = 1:length(algorithms)
        fprintf('%-12s | %-15.2f | %-15.2f | %-d\n',...
            alg_names{i}, card_rmse(i), tfr_vals(i), idsw_vals(i));
    end
end