
function [ground_truth_states, ground_truth_card] = generate_ground_truth(config)
    % Generates ground truth trajectories for multiple targets.
    % Creates a deterministic, scripted scenario with a varying number of targets over time.
    
    sim_steps = config.sim_steps;
    dt = config.dt;
    
    ground_truth_states = cell(sim_steps, 1);
    ground_truth_card = zeros(sim_steps, 1);
    
    % --- 关键修正：使用固定的、精心设计的起止时间来控制目标数量 ---
    % Format: {id, start_time, end_time, initial_state, model, params}
    maneuvers = {
        % 初始阶段 (k=1, 3个目标)
        {1, 1, 60, [-2000; 25; 500; 0], 'CV', []},
        {2, 1, 60, [-500; 0; -2000; 25], 'CV', []},
        {3, 1, 75, [-2000; 20; -200; 0], 'CV', []},
        
        % 第一波增长 (k=6, 5个目标)
        {4, 6, 75, [-2000; 20; -300; 0], 'CV', []},
        {5, 6, 95, [-1500; 20; 1000; 0], 'CV', []},
        
        % 第二波增长 (k=20, 7个目标)
        {6, 20, 95, [-2000; 20; 1500; 0], 'CV', []},
        {7, 20, 95, [2000; -15; 2000; -15], 'CV', []},
        
        % 达到峰值 (k=40, 8个目标)
        {8, 40, 95, [0; 10; -2000; 20], 'CV', []},
        
        % 后期新生目标，测试晚期响应 (k=90, 增加2个)
        {9, 90, 100, [-1000; 0; 1800; -15], 'CV', []},
        {10, 90, 100, [1500; -20; -1500; 10], 'CV', []}
    };

    % --- 后续代码保持不变 ---
    active_targets = {};
    for k = 1:sim_steps
        % --- Target Birth ---
        for i = 1:length(maneuvers)
            if maneuvers{i}{2} == k
                target.id = maneuvers{i}{1};
                target.state = maneuvers{i}{4};
                target.model = maneuvers{i}{5};
                target.params = maneuvers{i}{6};
                target.end_time = maneuvers{i}{3};
                active_targets{end+1} = target;
            end
        end
        
        % --- Target Propagation and Death ---
        next_active_targets = {};
        current_states = [];
        
        for i = 1:length(active_targets)
            target = active_targets{i};
            
            % Check for death (deterministic)
            if k > target.end_time
               continue; % Target dies only when its planned lifetime ends
            end

            % Propagate state
            if strcmp(target.model, 'CV')
                target.state = config.target.F_cv * target.state + ...
                               chol(config.target.Q_cv, 'lower') * randn(4,1);
            end
            
            % Check if target is within bounds
            if target.state(1) > config.area_x(1) && target.state(1) < config.area_x(2) && ...
               target.state(3) > config.area_y(1) && target.state(3) < config.area_y(2)
                next_active_targets{end+1} = target;
                current_states = [current_states, [target.state(1:4); target.id]];
            end
        end
        
        active_targets = next_active_targets;
        
        ground_truth_states{k} = current_states;
        ground_truth_card(k) = size(current_states, 2);
    end
end