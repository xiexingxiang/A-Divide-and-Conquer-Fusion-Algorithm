function fused_pmbm = fuse_WAA(local_pmbms, config)
    % Fuses local PMBM posteriors using Weighted Arithmetic Average (WAA)
    num_sensors = length(local_pmbms);
    fused_pmbm.ppp.w = 0;
    fused_pmbm.MBM = {};

    % --- 1. Fuse MBM component ---
    % Collect all unique tracks from local filters' best hypotheses
    track_pool = containers.Map('KeyType','double','ValueType','any');
    for s = 1:num_sensors
        if ~isempty(local_pmbms{s}.MBM)
            [~, best_h_idx] = max([local_pmbms{s}.MBM{:}.w]); 
            local_best_hyp = local_pmbms{s}.MBM{best_h_idx};
            if isfield(local_best_hyp, 'tracks')
                for i = 1:length(local_best_hyp.tracks)
                    track = local_best_hyp.tracks{i};
                    track.sensor_idx = s;  % Store sensor index
                    if ~isKey(track_pool, track.id)
                        track_pool(track.id) = {track};
                    else
                        existing_tracks = track_pool(track.id);
                        track_pool(track.id) = [existing_tracks, {track}];
                    end
                end
            end
        end
    end
    
    % Fuse each unique track using WAA
    fused_tracks = {};
    all_ids = keys(track_pool);
    for i = 1:length(all_ids)
        id = all_ids{i};
        tracks_to_fuse = track_pool(id);
        
        % Get the mean state to calculate weights
        mean_pos = tracks_to_fuse{1}.m([1, 3]);

        % Calculate state-dependent weights for this location
        [idx_min_sensor,weights] = calculate_waa_weights(mean_pos, local_pmbms, config);

        % Perform GCI-like fusion with these adaptive weights
        P_inv_fused = zeros(4,4);
        m_P_inv_fused = zeros(4,1);

        r_fused = 0;
        for j = 1:length(local_pmbms)
            if idx_min_sensor(j) ~= 0
                P_inv = inv(local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.P);
                P_inv_fused = P_inv_fused + weights(j) * P_inv;
                m_P_inv_fused = m_P_inv_fused + weights(j) * P_inv * local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.m;
                if local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.r > r_fused
                    r_fused = local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.r;
                end
                % r_fused = r_fused + (local_pmbms{j}.MBM{1}.tracks{1,idx_min_sensor(j)}.r * weights(j));
            end
        end

        fused_track.P = inv(P_inv_fused);
        fused_track.m = fused_track.P * m_P_inv_fused;
        fused_track.r = r_fused;
        fused_track.id = id;
        fused_tracks{end+1} = fused_track;
    end
    
    if ~isempty(fused_tracks)
        fused_pmbm.MBM{1}.w = 1.0;
        fused_pmbm.MBM{1}.tracks = fused_tracks;
        fused_pmbm.MBM{1}.id_counter = max([all_ids{:}]);
    end

    % --- 2. Fuse PPP component (unchanged) ---
    avg_weights = ones(1, num_sensors) / num_sensors;
    fused_intensity = 0;
    for s = 1:num_sensors
        fused_intensity = fused_intensity + avg_weights(s) * exp(local_pmbms{s}.ppp.w);
    end
    fused_pmbm.ppp.w = log(fused_intensity);
end