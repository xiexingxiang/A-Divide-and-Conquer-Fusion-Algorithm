%<file path="evaluation/evaluate_performance.m">
function [ospa_k, gospa_k, rmse_k] = evaluate_performance(estimated_tracks, ground_truth, config)
    % Calculates performance metrics for a single Monte Carlo run.
    
    sim_steps = config.sim_steps;
    ospa_k = zeros(sim_steps, 1);
    gospa_k = zeros(sim_steps, 1);
    rmse_k = zeros(sim_steps, 1);
        
   for k = 1:sim_steps
        % Check if the ground truth set is empty for this time step
        if isempty(ground_truth{k})
            X_true = []; % If so, create an empty set
        else
            X_true = ground_truth{k}(1:2, :); % If not empty, extract positions
        end
        
        % Check if the estimated track set is empty for this time step
        if isempty(estimated_tracks{k})
            X_est = []; % If so, create an empty set for the metric calculation
        else
            X_est = estimated_tracks{k}(1:2, :); % If not empty, extract positions
        end
        

        % Calculate OSPA and GOSPA
        [ospa_val, gospa_val] = calculate_ospa(X_est, X_true, config.eval.ospa_c, config.eval.ospa_p, config.eval.gospa_alpha);
        ospa_k(k) = ospa_val;
        gospa_k(k) = gospa_val;
        
        % Calculate RMSE for matched tracks
        if ~isempty(X_true) && ~isempty(X_est)
            % Find one-to-one assignment to calculate RMSE on matched pairs
            cost_matrix = pdist2(X_true', X_est');
            [assignment, ~] = matchpairs(cost_matrix', config.eval.ospa_c);
            
            if ~isempty(assignment)
                true_matched = X_true(:, assignment(:,2)); % <-- 修正
                est_matched = X_est(:, assignment(:,1));   % <-- 修正
                squared_errors = sum((true_matched - est_matched).^2, 1);
                rmse_k(k) = sqrt(mean(squared_errors));
            else
                rmse_k(k) = nan; % No matched tracks
            end
        else
            rmse_k(k) = nan;
        end
    end
end