%<file path="simulation_config.m">
function config = simulation_config()
% This function defines all parameters for the simulation environment,
% targets, sensors, and filters.

% --- General Simulation Parameters ---
config.num_mc_runs = 10;         % Number of Monte Carlo runs
config.sim_time = 100;           % Total simulation time in seconds
config.dt = 1;                   % Time step in seconds
config.sim_steps = config.sim_time / config.dt;

% --- Surveillance Area ---
config.area_x = [-2500, 2500];   % Surveillance area x-limits (m)
config.area_y = [-2500, 2500];   % Surveillance area y-limits (m)

% --- Target Model ---
config.target.num_targets = 10;  % Initial number of targets
config.target.ps = 0.99;         % Probability of survival
config.target.birth_rate = 0.1;  % Expected number of new targets per scan

% State vector: [x, vx, y, vy]'
% CV model
config.target.F_cv = [1 config.dt 0 0; 0 1 0 0; 0 0 1 config.dt; 0 0 0 1];
sigma_v_cv = 0.1; % m/s^2
config.target.Q_cv = sigma_v_cv^2 * [config.dt^4/4 config.dt^3/2 0 0;
    config.dt^3/2 config.dt^2 0 0;
    0 0 config.dt^4/4 config.dt^3/2;
    0 0 config.dt^3/2 config.dt^2];

config.target.Q_cv = config.target.Q_cv + eye(4) * 1e-9;

% CT model (turn rate omega is an additional state)
% State vector: [x, vx, y, vy, omega]'
% Note: The actual CT model is non-linear and handled in generate_ground_truth.m
sigma_v_ct = 0.1; % m/s^2
sigma_omega = deg2rad(0.5); % rad/s^2
config.target.Q_ct_process = diag([sigma_v_ct^2, sigma_omega^2]);

% --- Sensor Network Model ---
config.sensor.num_sensors = 6;
config.sensor.max_range = 3000; % m

% Sensor positions
angles = linspace(0, 2*pi, config.sensor.num_sensors + 1);
radius = 2000;
config.sensor.positions = radius * [cos(angles(1:end-1)); sin(angles(1:end-1))]';

% Measurement noise
% config.sensor.sigma_r = 10;      % Range standard deviation (m)
% config.sensor.sigma_theta = deg2rad(1); % Azimuth standard deviation (rad)
config.sensor.sigma_r = 1;      % Range standard deviation (m)
config.sensor.sigma_theta = deg2rad(0.1); % Azimuth standard deviation (rad)
config.sensor.R = diag([config.sensor.sigma_r^2, config.sensor.sigma_theta^2]);

% --- High-Challenge Scenario Parameters ---
% 1. Heterogeneous FoV
config.sensor.fov = repmat(360, config.sensor.num_sensors, 1); % Default 360 deg
config.sensor.fov(3) = 90; % Sensor 3 has a 90-degree FoV
config.sensor.fov(6) = 90; % Sensor 6 has a 90-degree FoV

% 2. Dynamic Occlusion Zone
config.occlusion.rect = [-1000, 1000, -500, 500]; % [xmin, xmax, ymin, ymax]
config.occlusion.pd_inside = 0.30; % Detection probability inside the zone
config.occlusion.pd_outside = 0.95; % Baseline detection probability
config.occlusion.sensors_affected = [1, 2]; % Sensors affected by this zone

% 3. Clutter Hotspot
config.clutter.hotspot_center = [-1500, 1500];
config.clutter.hotspot_radius = 500;
config.clutter.rate_hotspot = 30; % Clutter rate in hotspot
config.clutter.rate_background = 5; % Background clutter rate

% --- PMBM Filter Parameters ---
%config.filter.p_d = config.occlusion.pd_outside; % Use baseline Pd for general filter setup
config.filter.p_d = 0.99; % Assume a slightly lower Pd in the filter model
config.filter.birth_intensity_uniform = config.target.birth_rate /...
    ((config.area_x(2)-config.area_x(1)) * (config.area_y(2)-config.area_y(1)));
config.filter.pruning_threshold = 1e-4; % Pruning threshold for Bernoulli components (e.g., 5% confidence);
config.filter.max_hypotheses = 100;     % Max number of global hypotheses
config.filter.merging_threshold = 4;    % Merging threshold for hypotheses (Mahalanobis dist)

multi_merging = 40;
config.filter.waa_multi_merging_threshold = multi_merging;
config.filter.gci_multi_merging_threshold = multi_merging;
config.filter.sacw_multi_merging_threshold = multi_merging;
config.filter.plot_tra = 0;

% --- SACW-PMBM Specific Parameters ---
config.sacw.alpha = 0.6; % Balances entropy and environmental factors in weight calculation  alpha in [0,1]
config.sacw.beta = 2;  % Scales the environmental impact in VAE proxy

% --- Evaluation Parameters ---
config.eval.ospa_p = 1;
config.eval.ospa_c = 100; % OSPA cut-off distance (m)
config.eval.gospa_alpha = 2; % GOSPA alpha parameter
end